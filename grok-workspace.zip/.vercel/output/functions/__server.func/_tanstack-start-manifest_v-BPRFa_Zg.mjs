//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BPRFa_Zg.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DFk8Nf1v.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DFk8Nf1v.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DdUVWmgk.js"]
	}
} });
//#endregion
export { tsrStartManifest };
