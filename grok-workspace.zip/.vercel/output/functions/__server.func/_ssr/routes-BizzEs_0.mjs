import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as LayoutGrid, c as Heart, d as Check, f as ArrowLeft, i as Map$1, l as Earth, o as Landmark, r as RotateCcw, s as Keyboard, t as X, u as Compass } from "../_libs/lucide-react.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as T, i as N, n as A, r as C, t as y } from "../_libs/react-simple-maps+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BizzEs_0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COUNTRIES = [
	[
		"dz",
		"Algeria",
		"Algiers",
		"Africa",
		2
	],
	[
		"ao",
		"Angola",
		"Luanda",
		"Africa",
		3
	],
	[
		"bj",
		"Benin",
		"Porto-Novo",
		"Africa",
		3,
		[],
		["Porto Novo"]
	],
	[
		"bw",
		"Botswana",
		"Gaborone",
		"Africa",
		3
	],
	[
		"bf",
		"Burkina Faso",
		"Ouagadougou",
		"Africa",
		3
	],
	[
		"bi",
		"Burundi",
		"Gitega",
		"Africa",
		4,
		[],
		["Bujumbura"]
	],
	[
		"cv",
		"Cabo Verde",
		"Praia",
		"Africa",
		4,
		["Cape Verde"]
	],
	[
		"cm",
		"Cameroon",
		"Yaoundé",
		"Africa",
		3,
		[],
		["Yaounde"]
	],
	[
		"cf",
		"Central African Republic",
		"Bangui",
		"Africa",
		4,
		["CAR"]
	],
	[
		"td",
		"Chad",
		"N'Djamena",
		"Africa",
		3,
		[],
		["Ndjamena", "N Djamena"]
	],
	[
		"km",
		"Comoros",
		"Moroni",
		"Africa",
		4
	],
	[
		"cg",
		"Republic of the Congo",
		"Brazzaville",
		"Africa",
		3,
		["Congo", "Congo-Brazzaville"]
	],
	[
		"cd",
		"Democratic Republic of the Congo",
		"Kinshasa",
		"Africa",
		2,
		[
			"DRC",
			"DR Congo",
			"Congo-Kinshasa"
		]
	],
	[
		"ci",
		"Côte d'Ivoire",
		"Yamoussoukro",
		"Africa",
		2,
		["Ivory Coast", "Cote d'Ivoire"],
		["Abidjan"]
	],
	[
		"dj",
		"Djibouti",
		"Djibouti",
		"Africa",
		4
	],
	[
		"eg",
		"Egypt",
		"Cairo",
		"Africa",
		1
	],
	[
		"gq",
		"Equatorial Guinea",
		"Malabo",
		"Africa",
		4
	],
	[
		"er",
		"Eritrea",
		"Asmara",
		"Africa",
		4
	],
	[
		"sz",
		"Eswatini",
		"Mbabane",
		"Africa",
		4,
		["Swaziland"],
		["Lobamba"]
	],
	[
		"et",
		"Ethiopia",
		"Addis Ababa",
		"Africa",
		2
	],
	[
		"ga",
		"Gabon",
		"Libreville",
		"Africa",
		3
	],
	[
		"gm",
		"The Gambia",
		"Banjul",
		"Africa",
		4,
		["Gambia"]
	],
	[
		"gh",
		"Ghana",
		"Accra",
		"Africa",
		2
	],
	[
		"gn",
		"Guinea",
		"Conakry",
		"Africa",
		3
	],
	[
		"gw",
		"Guinea-Bissau",
		"Bissau",
		"Africa",
		4
	],
	[
		"ke",
		"Kenya",
		"Nairobi",
		"Africa",
		1
	],
	[
		"ls",
		"Lesotho",
		"Maseru",
		"Africa",
		4
	],
	[
		"lr",
		"Liberia",
		"Monrovia",
		"Africa",
		3
	],
	[
		"ly",
		"Libya",
		"Tripoli",
		"Africa",
		2
	],
	[
		"mg",
		"Madagascar",
		"Antananarivo",
		"Africa",
		2
	],
	[
		"mw",
		"Malawi",
		"Lilongwe",
		"Africa",
		3
	],
	[
		"ml",
		"Mali",
		"Bamako",
		"Africa",
		3
	],
	[
		"mr",
		"Mauritania",
		"Nouakchott",
		"Africa",
		3
	],
	[
		"mu",
		"Mauritius",
		"Port Louis",
		"Africa",
		3
	],
	[
		"ma",
		"Morocco",
		"Rabat",
		"Africa",
		2
	],
	[
		"mz",
		"Mozambique",
		"Maputo",
		"Africa",
		3
	],
	[
		"na",
		"Namibia",
		"Windhoek",
		"Africa",
		3
	],
	[
		"ne",
		"Niger",
		"Niamey",
		"Africa",
		3
	],
	[
		"ng",
		"Nigeria",
		"Abuja",
		"Africa",
		1,
		[],
		["Lagos"]
	],
	[
		"rw",
		"Rwanda",
		"Kigali",
		"Africa",
		2
	],
	[
		"st",
		"São Tomé and Príncipe",
		"São Tomé",
		"Africa",
		4,
		["Sao Tome and Principe"],
		["Sao Tome"]
	],
	[
		"sn",
		"Senegal",
		"Dakar",
		"Africa",
		2
	],
	[
		"sc",
		"Seychelles",
		"Victoria",
		"Africa",
		4
	],
	[
		"sl",
		"Sierra Leone",
		"Freetown",
		"Africa",
		3
	],
	[
		"so",
		"Somalia",
		"Mogadishu",
		"Africa",
		2
	],
	[
		"za",
		"South Africa",
		"Pretoria",
		"Africa",
		1,
		[],
		["Cape Town", "Bloemfontein"]
	],
	[
		"ss",
		"South Sudan",
		"Juba",
		"Africa",
		3
	],
	[
		"sd",
		"Sudan",
		"Khartoum",
		"Africa",
		2
	],
	[
		"tz",
		"Tanzania",
		"Dodoma",
		"Africa",
		2,
		[],
		["Dar es Salaam"]
	],
	[
		"tg",
		"Togo",
		"Lomé",
		"Africa",
		3,
		[],
		["Lome"]
	],
	[
		"tn",
		"Tunisia",
		"Tunis",
		"Africa",
		2
	],
	[
		"ug",
		"Uganda",
		"Kampala",
		"Africa",
		2
	],
	[
		"zm",
		"Zambia",
		"Lusaka",
		"Africa",
		3
	],
	[
		"zw",
		"Zimbabwe",
		"Harare",
		"Africa",
		2
	],
	[
		"ag",
		"Antigua and Barbuda",
		"St. John's",
		"Americas",
		4,
		[],
		["Saint John's", "St Johns"]
	],
	[
		"ar",
		"Argentina",
		"Buenos Aires",
		"Americas",
		1
	],
	[
		"bs",
		"The Bahamas",
		"Nassau",
		"Americas",
		2,
		["Bahamas"]
	],
	[
		"bb",
		"Barbados",
		"Bridgetown",
		"Americas",
		3
	],
	[
		"bz",
		"Belize",
		"Belmopan",
		"Americas",
		3
	],
	[
		"bo",
		"Bolivia",
		"Sucre",
		"Americas",
		2,
		[],
		["La Paz"]
	],
	[
		"br",
		"Brazil",
		"Brasília",
		"Americas",
		1,
		[],
		["Brasilia"]
	],
	[
		"ca",
		"Canada",
		"Ottawa",
		"Americas",
		1
	],
	[
		"cl",
		"Chile",
		"Santiago",
		"Americas",
		1
	],
	[
		"co",
		"Colombia",
		"Bogotá",
		"Americas",
		1,
		[],
		["Bogota"]
	],
	[
		"cr",
		"Costa Rica",
		"San José",
		"Americas",
		2,
		[],
		["San Jose"]
	],
	[
		"cu",
		"Cuba",
		"Havana",
		"Americas",
		1
	],
	[
		"dm",
		"Dominica",
		"Roseau",
		"Americas",
		4
	],
	[
		"do",
		"Dominican Republic",
		"Santo Domingo",
		"Americas",
		2
	],
	[
		"ec",
		"Ecuador",
		"Quito",
		"Americas",
		2
	],
	[
		"sv",
		"El Salvador",
		"San Salvador",
		"Americas",
		2
	],
	[
		"gd",
		"Grenada",
		"St. George's",
		"Americas",
		4,
		[],
		["Saint George's"]
	],
	[
		"gt",
		"Guatemala",
		"Guatemala City",
		"Americas",
		2
	],
	[
		"gy",
		"Guyana",
		"Georgetown",
		"Americas",
		3
	],
	[
		"ht",
		"Haiti",
		"Port-au-Prince",
		"Americas",
		2
	],
	[
		"hn",
		"Honduras",
		"Tegucigalpa",
		"Americas",
		3
	],
	[
		"jm",
		"Jamaica",
		"Kingston",
		"Americas",
		2
	],
	[
		"mx",
		"Mexico",
		"Mexico City",
		"Americas",
		1
	],
	[
		"ni",
		"Nicaragua",
		"Managua",
		"Americas",
		3
	],
	[
		"pa",
		"Panama",
		"Panama City",
		"Americas",
		2
	],
	[
		"py",
		"Paraguay",
		"Asunción",
		"Americas",
		3,
		[],
		["Asuncion"]
	],
	[
		"pe",
		"Peru",
		"Lima",
		"Americas",
		1
	],
	[
		"kn",
		"Saint Kitts and Nevis",
		"Basseterre",
		"Americas",
		4,
		["St. Kitts and Nevis", "St Kitts"]
	],
	[
		"lc",
		"Saint Lucia",
		"Castries",
		"Americas",
		4,
		["St. Lucia", "St Lucia"]
	],
	[
		"vc",
		"Saint Vincent and the Grenadines",
		"Kingstown",
		"Americas",
		4,
		["St. Vincent", "St Vincent"]
	],
	[
		"sr",
		"Suriname",
		"Paramaribo",
		"Americas",
		4
	],
	[
		"tt",
		"Trinidad and Tobago",
		"Port of Spain",
		"Americas",
		3
	],
	[
		"us",
		"United States",
		"Washington, D.C.",
		"Americas",
		1,
		[
			"USA",
			"United States of America",
			"US",
			"America"
		],
		["Washington", "Washington DC"]
	],
	[
		"uy",
		"Uruguay",
		"Montevideo",
		"Americas",
		2
	],
	[
		"ve",
		"Venezuela",
		"Caracas",
		"Americas",
		2
	],
	[
		"af",
		"Afghanistan",
		"Kabul",
		"Asia",
		2
	],
	[
		"am",
		"Armenia",
		"Yerevan",
		"Asia",
		3
	],
	[
		"az",
		"Azerbaijan",
		"Baku",
		"Asia",
		3
	],
	[
		"bh",
		"Bahrain",
		"Manama",
		"Asia",
		3
	],
	[
		"bd",
		"Bangladesh",
		"Dhaka",
		"Asia",
		2
	],
	[
		"bt",
		"Bhutan",
		"Thimphu",
		"Asia",
		3
	],
	[
		"bn",
		"Brunei",
		"Bandar Seri Begawan",
		"Asia",
		4
	],
	[
		"kh",
		"Cambodia",
		"Phnom Penh",
		"Asia",
		2
	],
	[
		"cn",
		"China",
		"Beijing",
		"Asia",
		1
	],
	[
		"cy",
		"Cyprus",
		"Nicosia",
		"Asia",
		2
	],
	[
		"ge",
		"Georgia",
		"Tbilisi",
		"Asia",
		2
	],
	[
		"in",
		"India",
		"New Delhi",
		"Asia",
		1,
		[],
		["Delhi"]
	],
	[
		"id",
		"Indonesia",
		"Jakarta",
		"Asia",
		1
	],
	[
		"ir",
		"Iran",
		"Tehran",
		"Asia",
		1
	],
	[
		"iq",
		"Iraq",
		"Baghdad",
		"Asia",
		2
	],
	[
		"il",
		"Israel",
		"Jerusalem",
		"Asia",
		1,
		[],
		["Tel Aviv"]
	],
	[
		"jp",
		"Japan",
		"Tokyo",
		"Asia",
		1
	],
	[
		"jo",
		"Jordan",
		"Amman",
		"Asia",
		2
	],
	[
		"kz",
		"Kazakhstan",
		"Astana",
		"Asia",
		2,
		[],
		["Nur-Sultan", "Nursultan"]
	],
	[
		"kw",
		"Kuwait",
		"Kuwait City",
		"Asia",
		2
	],
	[
		"kg",
		"Kyrgyzstan",
		"Bishkek",
		"Asia",
		4
	],
	[
		"la",
		"Laos",
		"Vientiane",
		"Asia",
		3
	],
	[
		"lb",
		"Lebanon",
		"Beirut",
		"Asia",
		2
	],
	[
		"my",
		"Malaysia",
		"Kuala Lumpur",
		"Asia",
		1
	],
	[
		"mv",
		"Maldives",
		"Malé",
		"Asia",
		3,
		[],
		["Male"]
	],
	[
		"mn",
		"Mongolia",
		"Ulaanbaatar",
		"Asia",
		3,
		[],
		["Ulan Bator"]
	],
	[
		"mm",
		"Myanmar",
		"Naypyidaw",
		"Asia",
		2,
		["Burma"],
		[
			"Nay Pyi Taw",
			"Rangoon",
			"Yangon"
		]
	],
	[
		"np",
		"Nepal",
		"Kathmandu",
		"Asia",
		2
	],
	[
		"kp",
		"North Korea",
		"Pyongyang",
		"Asia",
		1,
		["DPRK", "Democratic People's Republic of Korea"]
	],
	[
		"om",
		"Oman",
		"Muscat",
		"Asia",
		3
	],
	[
		"pk",
		"Pakistan",
		"Islamabad",
		"Asia",
		1
	],
	[
		"ph",
		"Philippines",
		"Manila",
		"Asia",
		1
	],
	[
		"qa",
		"Qatar",
		"Doha",
		"Asia",
		2
	],
	[
		"sa",
		"Saudi Arabia",
		"Riyadh",
		"Asia",
		1
	],
	[
		"sg",
		"Singapore",
		"Singapore",
		"Asia",
		1
	],
	[
		"kr",
		"South Korea",
		"Seoul",
		"Asia",
		1,
		["Korea", "Republic of Korea"]
	],
	[
		"lk",
		"Sri Lanka",
		"Sri Jayawardenepura Kotte",
		"Asia",
		2,
		[],
		["Colombo", "Kotte"]
	],
	[
		"sy",
		"Syria",
		"Damascus",
		"Asia",
		2
	],
	[
		"tj",
		"Tajikistan",
		"Dushanbe",
		"Asia",
		4
	],
	[
		"th",
		"Thailand",
		"Bangkok",
		"Asia",
		1
	],
	[
		"tl",
		"Timor-Leste",
		"Dili",
		"Asia",
		4,
		["East Timor"]
	],
	[
		"tr",
		"Turkey",
		"Ankara",
		"Asia",
		1,
		["Türkiye", "Turkiye"]
	],
	[
		"tm",
		"Turkmenistan",
		"Ashgabat",
		"Asia",
		4,
		[],
		["Ashkhabad"]
	],
	[
		"ae",
		"United Arab Emirates",
		"Abu Dhabi",
		"Asia",
		1,
		["UAE"]
	],
	[
		"uz",
		"Uzbekistan",
		"Tashkent",
		"Asia",
		3
	],
	[
		"vn",
		"Vietnam",
		"Hanoi",
		"Asia",
		1
	],
	[
		"ye",
		"Yemen",
		"Sana'a",
		"Asia",
		3,
		[],
		["Sanaa"]
	],
	[
		"al",
		"Albania",
		"Tirana",
		"Europe",
		2
	],
	[
		"ad",
		"Andorra",
		"Andorra la Vella",
		"Europe",
		4
	],
	[
		"at",
		"Austria",
		"Vienna",
		"Europe",
		1
	],
	[
		"by",
		"Belarus",
		"Minsk",
		"Europe",
		2
	],
	[
		"be",
		"Belgium",
		"Brussels",
		"Europe",
		1
	],
	[
		"ba",
		"Bosnia and Herzegovina",
		"Sarajevo",
		"Europe",
		2,
		["Bosnia"]
	],
	[
		"bg",
		"Bulgaria",
		"Sofia",
		"Europe",
		2
	],
	[
		"hr",
		"Croatia",
		"Zagreb",
		"Europe",
		2
	],
	[
		"cz",
		"Czechia",
		"Prague",
		"Europe",
		1,
		["Czech Republic"]
	],
	[
		"dk",
		"Denmark",
		"Copenhagen",
		"Europe",
		1
	],
	[
		"ee",
		"Estonia",
		"Tallinn",
		"Europe",
		2
	],
	[
		"fi",
		"Finland",
		"Helsinki",
		"Europe",
		1
	],
	[
		"fr",
		"France",
		"Paris",
		"Europe",
		1
	],
	[
		"de",
		"Germany",
		"Berlin",
		"Europe",
		1
	],
	[
		"gr",
		"Greece",
		"Athens",
		"Europe",
		1
	],
	[
		"hu",
		"Hungary",
		"Budapest",
		"Europe",
		1
	],
	[
		"is",
		"Iceland",
		"Reykjavík",
		"Europe",
		2,
		[],
		["Reykjavik"]
	],
	[
		"ie",
		"Ireland",
		"Dublin",
		"Europe",
		1
	],
	[
		"it",
		"Italy",
		"Rome",
		"Europe",
		1
	],
	[
		"lv",
		"Latvia",
		"Riga",
		"Europe",
		2
	],
	[
		"li",
		"Liechtenstein",
		"Vaduz",
		"Europe",
		4
	],
	[
		"lt",
		"Lithuania",
		"Vilnius",
		"Europe",
		2
	],
	[
		"lu",
		"Luxembourg",
		"Luxembourg",
		"Europe",
		2,
		[],
		["Luxembourg City"]
	],
	[
		"mt",
		"Malta",
		"Valletta",
		"Europe",
		2
	],
	[
		"md",
		"Moldova",
		"Chișinău",
		"Europe",
		3,
		[],
		["Chisinau"]
	],
	[
		"mc",
		"Monaco",
		"Monaco",
		"Europe",
		3
	],
	[
		"me",
		"Montenegro",
		"Podgorica",
		"Europe",
		3
	],
	[
		"nl",
		"Netherlands",
		"Amsterdam",
		"Europe",
		1,
		["Holland"],
		["The Hague", "Den Haag"]
	],
	[
		"mk",
		"North Macedonia",
		"Skopje",
		"Europe",
		3,
		["Macedonia"]
	],
	[
		"no",
		"Norway",
		"Oslo",
		"Europe",
		1
	],
	[
		"pl",
		"Poland",
		"Warsaw",
		"Europe",
		1
	],
	[
		"pt",
		"Portugal",
		"Lisbon",
		"Europe",
		1
	],
	[
		"ro",
		"Romania",
		"Bucharest",
		"Europe",
		2
	],
	[
		"ru",
		"Russia",
		"Moscow",
		"Europe",
		1
	],
	[
		"sm",
		"San Marino",
		"San Marino",
		"Europe",
		4
	],
	[
		"rs",
		"Serbia",
		"Belgrade",
		"Europe",
		2
	],
	[
		"sk",
		"Slovakia",
		"Bratislava",
		"Europe",
		2
	],
	[
		"si",
		"Slovenia",
		"Ljubljana",
		"Europe",
		2
	],
	[
		"es",
		"Spain",
		"Madrid",
		"Europe",
		1
	],
	[
		"se",
		"Sweden",
		"Stockholm",
		"Europe",
		1
	],
	[
		"ch",
		"Switzerland",
		"Bern",
		"Europe",
		1,
		[],
		["Berne"]
	],
	[
		"ua",
		"Ukraine",
		"Kyiv",
		"Europe",
		1,
		[],
		["Kiev"]
	],
	[
		"gb",
		"United Kingdom",
		"London",
		"Europe",
		1,
		[
			"UK",
			"Great Britain",
			"Britain",
			"England"
		]
	],
	[
		"au",
		"Australia",
		"Canberra",
		"Oceania",
		1
	],
	[
		"fj",
		"Fiji",
		"Suva",
		"Oceania",
		2
	],
	[
		"ki",
		"Kiribati",
		"South Tarawa",
		"Oceania",
		4,
		[],
		["Tarawa"]
	],
	[
		"mh",
		"Marshall Islands",
		"Majuro",
		"Oceania",
		4
	],
	[
		"fm",
		"Micronesia",
		"Palikir",
		"Oceania",
		4,
		["Federated States of Micronesia"]
	],
	[
		"nr",
		"Nauru",
		"Yaren",
		"Oceania",
		4
	],
	[
		"nz",
		"New Zealand",
		"Wellington",
		"Oceania",
		1
	],
	[
		"pw",
		"Palau",
		"Ngerulmud",
		"Oceania",
		4
	],
	[
		"pg",
		"Papua New Guinea",
		"Port Moresby",
		"Oceania",
		3
	],
	[
		"ws",
		"Samoa",
		"Apia",
		"Oceania",
		3
	],
	[
		"sb",
		"Solomon Islands",
		"Honiara",
		"Oceania",
		4
	],
	[
		"to",
		"Tonga",
		"Nuku'alofa",
		"Oceania",
		4,
		[],
		["Nukualofa"]
	],
	[
		"tv",
		"Tuvalu",
		"Funafuti",
		"Oceania",
		4
	],
	[
		"vu",
		"Vanuatu",
		"Port Vila",
		"Oceania",
		4
	],
	[
		"va",
		"Vatican City",
		"Vatican City",
		"Europe",
		2,
		["Holy See", "Vatican"],
		[],
		true
	],
	[
		"ps",
		"Palestine",
		"Ramallah",
		"Asia",
		2,
		[],
		["East Jerusalem", "Jerusalem"],
		true
	],
	[
		"tw",
		"Taiwan",
		"Taipei",
		"Asia",
		1,
		["Republic of China"],
		[],
		true
	],
	[
		"xk",
		"Kosovo",
		"Pristina",
		"Europe",
		3,
		[],
		["Prishtina"],
		true
	],
	[
		"hk",
		"Hong Kong",
		"Hong Kong",
		"Asia",
		1,
		[],
		[],
		true
	],
	[
		"mo",
		"Macau",
		"Macau",
		"Asia",
		3,
		["Macao"],
		[],
		true
	],
	[
		"pr",
		"Puerto Rico",
		"San Juan",
		"Americas",
		2,
		[],
		[],
		true
	],
	[
		"gl",
		"Greenland",
		"Nuuk",
		"Americas",
		2,
		[],
		[],
		true
	],
	[
		"fo",
		"Faroe Islands",
		"Tórshavn",
		"Europe",
		4,
		[],
		["Torshavn"],
		true
	],
	[
		"gi",
		"Gibraltar",
		"Gibraltar",
		"Europe",
		3,
		[],
		[],
		true
	],
	[
		"nc",
		"New Caledonia",
		"Nouméa",
		"Oceania",
		4,
		[],
		["Noumea"],
		true
	],
	[
		"pf",
		"French Polynesia",
		"Papeete",
		"Oceania",
		4,
		[],
		[],
		true
	],
	[
		"gu",
		"Guam",
		"Hagåtña",
		"Oceania",
		4,
		[],
		["Hagatna", "Agana"],
		true
	],
	[
		"as",
		"American Samoa",
		"Pago Pago",
		"Oceania",
		4,
		[],
		[],
		true
	],
	[
		"mp",
		"Northern Mariana Islands",
		"Saipan",
		"Oceania",
		4,
		[],
		[],
		true
	],
	[
		"vi",
		"U.S. Virgin Islands",
		"Charlotte Amalie",
		"Americas",
		4,
		["US Virgin Islands"],
		[],
		true
	],
	[
		"vg",
		"British Virgin Islands",
		"Road Town",
		"Americas",
		4,
		[],
		[],
		true
	],
	[
		"ky",
		"Cayman Islands",
		"George Town",
		"Americas",
		4,
		[],
		[],
		true
	],
	[
		"bm",
		"Bermuda",
		"Hamilton",
		"Americas",
		3,
		[],
		[],
		true
	],
	[
		"aw",
		"Aruba",
		"Oranjestad",
		"Americas",
		3,
		[],
		[],
		true
	],
	[
		"cw",
		"Curaçao",
		"Willemstad",
		"Americas",
		4,
		["Curacao"],
		[],
		true
	],
	[
		"sx",
		"Sint Maarten",
		"Philipsburg",
		"Americas",
		4,
		[],
		[],
		true
	],
	[
		"gp",
		"Guadeloupe",
		"Basse-Terre",
		"Americas",
		4,
		[],
		[],
		true
	],
	[
		"mq",
		"Martinique",
		"Fort-de-France",
		"Americas",
		4,
		[],
		[],
		true
	],
	[
		"gf",
		"French Guiana",
		"Cayenne",
		"Americas",
		4,
		[],
		[],
		true
	],
	[
		"re",
		"Réunion",
		"Saint-Denis",
		"Africa",
		4,
		["Reunion"],
		[],
		true
	],
	[
		"yt",
		"Mayotte",
		"Mamoudzou",
		"Africa",
		4,
		[],
		[],
		true
	],
	[
		"eh",
		"Western Sahara",
		"Laayoune",
		"Africa",
		4,
		[],
		["El Aaiún"],
		true
	],
	[
		"ck",
		"Cook Islands",
		"Avarua",
		"Oceania",
		4,
		[],
		[],
		true
	],
	[
		"nu",
		"Niue",
		"Alofi",
		"Oceania",
		4,
		[],
		[],
		true
	],
	[
		"wf",
		"Wallis and Futuna",
		"Mata-Utu",
		"Oceania",
		4,
		[],
		[],
		true
	],
	[
		"tc",
		"Turks and Caicos Islands",
		"Cockburn Town",
		"Americas",
		4,
		[],
		[],
		true
	],
	[
		"im",
		"Isle of Man",
		"Douglas",
		"Europe",
		4,
		[],
		[],
		true
	],
	[
		"je",
		"Jersey",
		"Saint Helier",
		"Europe",
		4,
		[],
		[],
		true
	],
	[
		"gg",
		"Guernsey",
		"Saint Peter Port",
		"Europe",
		4,
		[],
		[],
		true
	],
	[
		"ax",
		"Åland Islands",
		"Mariehamn",
		"Europe",
		4,
		["Aland"],
		[],
		true
	],
	[
		"fk",
		"Falkland Islands",
		"Stanley",
		"Americas",
		4,
		[],
		[],
		true
	],
	[
		"pm",
		"Saint Pierre and Miquelon",
		"Saint-Pierre",
		"Americas",
		4,
		[],
		[],
		true
	],
	[
		"bl",
		"Saint Barthélemy",
		"Gustavia",
		"Americas",
		4,
		["Saint Barthelemy", "St. Barts"],
		[],
		true
	],
	[
		"mf",
		"Saint Martin",
		"Marigot",
		"Americas",
		4,
		[],
		[],
		true
	],
	[
		"bq",
		"Caribbean Netherlands",
		"Kralendijk",
		"Americas",
		4,
		["Bonaire"],
		[],
		true
	],
	[
		"ai",
		"Anguilla",
		"The Valley",
		"Americas",
		4,
		[],
		[],
		true
	],
	[
		"ms",
		"Montserrat",
		"Plymouth",
		"Americas",
		4,
		[],
		["Brades"],
		true
	],
	[
		"sh",
		"Saint Helena",
		"Jamestown",
		"Africa",
		4,
		[],
		[],
		true
	],
	[
		"io",
		"British Indian Ocean Territory",
		"Diego Garcia",
		"Asia",
		4,
		[],
		[],
		true
	],
	[
		"cx",
		"Christmas Island",
		"Flying Fish Cove",
		"Oceania",
		4,
		[],
		[],
		true
	],
	[
		"cc",
		"Cocos Islands",
		"West Island",
		"Oceania",
		4,
		["Keeling Islands"],
		[],
		true
	],
	[
		"nf",
		"Norfolk Island",
		"Kingston",
		"Oceania",
		4,
		[],
		[],
		true
	],
	[
		"tk",
		"Tokelau",
		"Atafu",
		"Oceania",
		4,
		[],
		[],
		true
	],
	[
		"pn",
		"Pitcairn Islands",
		"Adamstown",
		"Oceania",
		4,
		[],
		[],
		true
	]
].map(([iso, name, capital, region, tier, aliases, capitalAliases, extra]) => ({
	iso,
	name,
	capital,
	region,
	tier,
	aliases: aliases ?? [],
	capitalAliases: capitalAliases ?? [],
	extra: extra || void 0
}));
var CORE_COUNTRIES = COUNTRIES.filter((c) => !c.extra);
var REGIONS = [
	"Africa",
	"Americas",
	"Asia",
	"Europe",
	"Oceania"
];
function flagUrl(iso, width = 320) {
	return `https://flagcdn.com/w${width}/${iso}.png`;
}
function flagSrcSet(iso) {
	return `${flagUrl(iso, 160)} 160w, ${flagUrl(iso, 320)} 320w, ${flagUrl(iso, 640)} 640w`;
}
function poolFor(opts) {
	let list = opts.includeExtras ? COUNTRIES : CORE_COUNTRIES;
	if (opts.region !== "World") list = list.filter((c) => c.region === opts.region);
	return list;
}
var LENGTH_COUNTS = {
	sprint: 10,
	classic: 20,
	marathon: 50
};
function shuffle(arr) {
	const a = [...arr];
	for (let i = a.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[a[i], a[j]] = [a[j], a[i]];
	}
	return a;
}
function pickKind(mode) {
	if (mode === "flags") return "flag";
	if (mode === "capitals") return "capital";
	if (mode === "reverse") return "reverse";
	if (mode === "map") return "map";
	const roll = Math.random();
	if (roll < .28) return "flag";
	if (roll < .5) return "capital";
	if (roll < .7) return "reverse";
	return "map";
}
function distractors(correct, pool, field, n) {
	const same = pool.filter((c) => c.iso !== correct.iso && c.region === correct.region);
	const rest = pool.filter((c) => c.iso !== correct.iso && c.region !== correct.region);
	const chosen = [];
	const take = (src) => {
		for (const c of shuffle(src)) {
			if (chosen.length >= n) break;
			const val = c[field];
			if (val === correct[field]) continue;
			if (chosen.some((x) => x[field] === val)) continue;
			chosen.push(c);
		}
	};
	take(same);
	take(rest);
	return chosen.map((c) => c[field]);
}
function makeQuestion(pool, mode, used) {
	const unused = pool.filter((c) => !used.has(c.iso));
	const source = unused.length > 3 ? unused : pool;
	if (source.length < 4) return null;
	const country = source[Math.floor(Math.random() * source.length)];
	const kind = pickKind(mode);
	if (kind === "flag") {
		const opts = shuffle([country.name, ...distractors(country, pool, "name", 3)]);
		return {
			id: `${country.iso}-flag-${Math.random().toString(36).slice(2, 7)}`,
			kind,
			prompt: "Which country flies this flag?",
			country,
			options: opts,
			answer: country.name
		};
	}
	if (kind === "capital") {
		const opts = shuffle([country.capital, ...distractors(country, pool, "capital", 3)]);
		return {
			id: `${country.iso}-cap-${Math.random().toString(36).slice(2, 7)}`,
			kind,
			prompt: `What is the capital of ${country.name}?`,
			country,
			options: opts,
			answer: country.capital
		};
	}
	if (kind === "map") {
		const byCapital = Math.random() < .5;
		return {
			id: `${country.iso}-map-${Math.random().toString(36).slice(2, 7)}`,
			kind,
			prompt: byCapital ? `Tap the country whose capital is ${country.capital}.` : `Tap ${country.name} on the map.`,
			country,
			options: [],
			answer: country.name
		};
	}
	const opts = shuffle([country.name, ...distractors(country, pool, "name", 3)]);
	return {
		id: `${country.iso}-rev-${Math.random().toString(36).slice(2, 7)}`,
		kind,
		prompt: `${country.capital} is the capital of which country?`,
		country,
		options: opts,
		answer: country.name
	};
}
function buildRound(pool, config) {
	const filtered = pool.filter((c) => c.tier <= config.maxTier);
	const usable = filtered.length >= 8 ? filtered : pool;
	const count = config.length === "survival" ? Math.min(usable.length, 200) : LENGTH_COUNTS[config.length];
	const used = /* @__PURE__ */ new Set();
	const qs = [];
	for (let i = 0; i < count; i++) {
		const q = makeQuestion(usable, config.mode, used);
		if (!q) break;
		used.add(q.country.iso);
		qs.push(q);
	}
	return qs;
}
function acceptedAnswers(q) {
	if (q.kind === "capital") return [q.country.capital, ...q.country.capitalAliases];
	return [q.country.name, ...q.country.aliases];
}
function foldName(s) {
	return s.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase().replace(/&/g, " and ").replace(/\bsaint\b/g, "st").replace(/\bst\./g, "st").replace(/[^a-z0-9 ]/g, " ").replace(/\bthe\b/g, " ").replace(/\bcity\b/g, " ").replace(/\s+/g, " ").trim();
}
function levenshtein(a, b) {
	if (a === b) return 0;
	if (!a.length) return b.length;
	if (!b.length) return a.length;
	const row = Array.from({ length: b.length + 1 }, (_, i) => i);
	for (let i = 1; i <= a.length; i++) {
		let prev = i - 1;
		row[0] = i;
		for (let j = 1; j <= b.length; j++) {
			const tmp = row[j];
			const cost = a[i - 1] === b[j - 1] ? 0 : 1;
			row[j] = Math.min(row[j] + 1, row[j - 1] + 1, prev + cost);
			prev = tmp;
		}
	}
	return row[b.length];
}
function closeEnough(typed, target) {
	if (typed === target) return true;
	if (!typed || !target) return false;
	if (target.startsWith(typed) && typed.length >= Math.max(6, Math.ceil(target.length * .7))) return true;
	const dist = levenshtein(typed, target);
	if (target.length >= 12) return dist <= 2;
	if (target.length >= 5) return dist <= 1;
	return false;
}
function gradeWritten(input, q) {
	const typed = foldName(input);
	if (!typed) return false;
	return acceptedAnswers(q).some((a) => closeEnough(typed, foldName(a)));
}
var MODE_COPY = {
	flags: {
		title: "Flags",
		blurb: "Match the banner to the nation."
	},
	capitals: {
		title: "Capitals",
		blurb: "Name the seat of government."
	},
	reverse: {
		title: "From the capital",
		blurb: "A city is given. Find the country."
	},
	map: {
		title: "Map",
		blurb: "Tap the country. Capitals light up."
	},
	mixed: {
		title: "Mixed atlas",
		blurb: "Flags, capitals, writing, and the map."
	}
};
var LENGTH_COPY = {
	sprint: {
		title: "Sprint · 10",
		blurb: "Ten questions"
	},
	classic: {
		title: "Classic · 20",
		blurb: "Twenty questions"
	},
	marathon: {
		title: "Marathon · 50",
		blurb: "Fifty questions"
	},
	survival: {
		title: "Survival",
		blurb: "Three misses and you are out"
	}
};
var KEY = "meridian-progress-v1";
var VERSION = 1;
var empty = {
	version: VERSION,
	mastered: [],
	best: {},
	games: 0,
	correct: 0,
	asked: 0
};
function read() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return {
			...empty,
			mastered: [],
			best: {}
		};
		const parsed = JSON.parse(raw);
		return {
			...empty,
			...parsed,
			version: VERSION,
			mastered: Array.isArray(parsed.mastered) ? parsed.mastered : [],
			best: parsed.best && typeof parsed.best === "object" ? parsed.best : {},
			games: Number(parsed.games) || 0,
			correct: Number(parsed.correct) || 0,
			asked: Number(parsed.asked) || 0
		};
	} catch {
		return {
			...empty,
			mastered: [],
			best: {}
		};
	}
}
function write(p) {
	try {
		localStorage.setItem(KEY, JSON.stringify(p));
	} catch {}
}
function loadProgress() {
	if (typeof window === "undefined") return {
		...empty,
		mastered: [],
		best: {}
	};
	return read();
}
function recordRound(opts) {
	const p = read();
	p.games += 1;
	p.correct += opts.score;
	p.asked += opts.asked;
	const set = new Set(p.mastered);
	for (const iso of opts.hits) set.add(iso);
	p.mastered = [...set];
	const prev = p.best[opts.key] ?? 0;
	if (opts.score > prev) p.best[opts.key] = opts.score;
	write(p);
	return p;
}
function roundKey(mode, length, region, extras, tier) {
	return `${mode}|${length}|${region}|${extras ? "x" : "c"}|t${tier}`;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,color,border-color] duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] select-none", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-raised text-fg border border-border hover:border-border-strong",
			ghost: "text-muted hover:text-fg hover:bg-raised",
			sage: "bg-sage text-sage-fg hover:opacity-90",
			rust: "bg-rust text-rust-fg hover:opacity-90"
		},
		size: {
			sm: "h-9 px-3 text-sm rounded-sm",
			md: "h-11 px-4 text-sm rounded-md",
			lg: "h-12 px-5 text-base rounded-md",
			xl: "h-14 px-6 text-base rounded-lg"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var geo_data_default = {
	numeric: {
		"aw": "533",
		"af": "004",
		"ao": "024",
		"ai": "660",
		"ax": "248",
		"al": "008",
		"ad": "020",
		"ae": "784",
		"ar": "032",
		"am": "051",
		"as": "016",
		"aq": "010",
		"tf": "260",
		"ag": "028",
		"au": "036",
		"at": "040",
		"az": "031",
		"bi": "108",
		"be": "056",
		"bj": "204",
		"bf": "854",
		"bd": "050",
		"bg": "100",
		"bh": "048",
		"bs": "044",
		"ba": "070",
		"bl": "652",
		"sh": "654",
		"by": "112",
		"bz": "084",
		"bm": "060",
		"bo": "068",
		"bq": "535",
		"br": "076",
		"bb": "052",
		"bn": "096",
		"bt": "064",
		"bv": "074",
		"bw": "072",
		"cf": "140",
		"ca": "124",
		"cc": "166",
		"ch": "756",
		"cl": "152",
		"cn": "156",
		"ci": "384",
		"cm": "120",
		"cd": "180",
		"cg": "178",
		"ck": "184",
		"co": "170",
		"km": "174",
		"cv": "132",
		"cr": "188",
		"cu": "192",
		"cw": "531",
		"cx": "162",
		"ky": "136",
		"cy": "196",
		"cz": "203",
		"de": "276",
		"dj": "262",
		"dm": "212",
		"dk": "208",
		"do": "214",
		"dz": "012",
		"ec": "218",
		"eg": "818",
		"er": "232",
		"eh": "732",
		"es": "724",
		"ee": "233",
		"et": "231",
		"fi": "246",
		"fj": "242",
		"fk": "238",
		"fr": "250",
		"fo": "234",
		"fm": "583",
		"ga": "266",
		"gb": "826",
		"ge": "268",
		"gg": "831",
		"gh": "288",
		"gi": "292",
		"gn": "324",
		"gp": "312",
		"gm": "270",
		"gw": "624",
		"gq": "226",
		"gr": "300",
		"gd": "308",
		"gl": "304",
		"gt": "320",
		"gf": "254",
		"gu": "316",
		"gy": "328",
		"hk": "344",
		"hm": "334",
		"hn": "340",
		"hr": "191",
		"ht": "332",
		"hu": "348",
		"id": "360",
		"im": "833",
		"in": "356",
		"io": "086",
		"ie": "372",
		"ir": "364",
		"iq": "368",
		"is": "352",
		"il": "376",
		"it": "380",
		"jm": "388",
		"je": "832",
		"jo": "400",
		"jp": "392",
		"kz": "398",
		"ke": "404",
		"kg": "417",
		"kh": "116",
		"ki": "296",
		"kn": "659",
		"kr": "410",
		"kw": "414",
		"la": "418",
		"lb": "422",
		"lr": "430",
		"ly": "434",
		"lc": "662",
		"li": "438",
		"lk": "144",
		"ls": "426",
		"lt": "440",
		"lu": "442",
		"lv": "428",
		"mo": "446",
		"mf": "663",
		"ma": "504",
		"mc": "492",
		"md": "498",
		"mg": "450",
		"mv": "462",
		"mx": "484",
		"mh": "584",
		"mk": "807",
		"ml": "466",
		"mt": "470",
		"mm": "104",
		"me": "499",
		"mn": "496",
		"mp": "580",
		"mz": "508",
		"mr": "478",
		"ms": "500",
		"mq": "474",
		"mu": "480",
		"mw": "454",
		"my": "458",
		"yt": "175",
		"na": "516",
		"nc": "540",
		"ne": "562",
		"nf": "574",
		"ng": "566",
		"ni": "558",
		"nu": "570",
		"nl": "528",
		"no": "578",
		"np": "524",
		"nr": "520",
		"nz": "554",
		"om": "512",
		"pk": "586",
		"pa": "591",
		"pn": "612",
		"pe": "604",
		"ph": "608",
		"pw": "585",
		"pg": "598",
		"pl": "616",
		"pr": "630",
		"kp": "408",
		"pt": "620",
		"py": "600",
		"ps": "275",
		"pf": "258",
		"qa": "634",
		"re": "638",
		"ro": "642",
		"ru": "643",
		"rw": "646",
		"sa": "682",
		"sd": "729",
		"sn": "686",
		"sg": "702",
		"gs": "239",
		"sj": "744",
		"sb": "090",
		"sl": "694",
		"sv": "222",
		"sm": "674",
		"so": "706",
		"pm": "666",
		"rs": "688",
		"ss": "728",
		"st": "678",
		"sr": "740",
		"sk": "703",
		"si": "705",
		"se": "752",
		"sz": "748",
		"sx": "534",
		"sc": "690",
		"sy": "760",
		"tc": "796",
		"td": "148",
		"tg": "768",
		"th": "764",
		"tj": "762",
		"tk": "772",
		"tm": "795",
		"tl": "626",
		"to": "776",
		"tt": "780",
		"tn": "788",
		"tr": "792",
		"tv": "798",
		"tw": "158",
		"tz": "834",
		"ug": "800",
		"ua": "804",
		"um": "581",
		"uy": "858",
		"us": "840",
		"uz": "860",
		"va": "336",
		"vc": "670",
		"ve": "862",
		"vg": "092",
		"vi": "850",
		"vn": "704",
		"vu": "548",
		"wf": "876",
		"ws": "882",
		"ye": "887",
		"za": "710",
		"zm": "894",
		"zw": "716",
		"xk": "983"
	},
	capital: {
		"aw": [-69.96666666, 12.5],
		"af": [65, 33],
		"ao": [18.5, -12.5],
		"ai": [-63.16666666, 18.25],
		"ax": [19.9, 60.116667],
		"al": [20, 41],
		"ad": [1.5, 42.5],
		"ae": [54, 24],
		"ar": [-64, -34],
		"am": [45, 40],
		"as": [-170, -14.33333333],
		"aq": [0, -90],
		"tf": [69.167, -49.25],
		"ag": [-61.8, 17.05],
		"au": [133, -27],
		"at": [13.33333333, 47.33333333],
		"az": [47.5, 40.5],
		"bi": [30, -3.5],
		"be": [4, 50.83333333],
		"bj": [2.25, 9.5],
		"bf": [-2, 13],
		"bd": [90, 24],
		"bg": [25, 43],
		"bh": [50.55, 26],
		"bs": [-76, 24.25],
		"ba": [18, 44],
		"bl": [-63.41666666, 18.5],
		"sh": [-5.72, -15.95],
		"by": [28, 53],
		"bz": [-88.75, 17.25],
		"bm": [-64.75, 32.33333333],
		"bo": [-65, -17],
		"bq": [-68.25, 12.18],
		"br": [-55, -10],
		"bb": [-59.53333333, 13.16666666],
		"bn": [114.66666666, 4.5],
		"bt": [90.5, 27.5],
		"bv": [3.4, -54.43333333],
		"bw": [24, -22],
		"cf": [21, 7],
		"ca": [-95, 60],
		"cc": [96.83333333, -12.5],
		"ch": [8, 47],
		"cl": [-71, -30],
		"cn": [105, 35],
		"ci": [-5, 8],
		"cm": [12, 6],
		"cd": [25, 0],
		"cg": [15, -1],
		"ck": [-159.76666666, -21.23333333],
		"co": [-72, 4],
		"km": [44.25, -12.16666666],
		"cv": [-24, 16],
		"cr": [-84, 10],
		"cu": [-80, 21.5],
		"cw": [-68.933333, 12.116667],
		"cx": [105.66666666, -10.5],
		"ky": [-80.5, 19.5],
		"cy": [33, 35],
		"cz": [15.5, 49.75],
		"de": [9, 51],
		"dj": [43, 11.5],
		"dm": [-61.33333333, 15.41666666],
		"dk": [10, 56],
		"do": [-70.66666666, 19],
		"dz": [3, 28],
		"ec": [-77.5, -2],
		"eg": [30, 27],
		"er": [39, 15],
		"eh": [-13, 24.5],
		"es": [-4, 40],
		"ee": [26, 59],
		"et": [38, 8],
		"fi": [26, 64],
		"fj": [175, -18],
		"fk": [-59, -51.75],
		"fr": [2, 46],
		"fo": [-7, 62],
		"fm": [158.25, 6.91666666],
		"ga": [11.75, -1],
		"gb": [-2, 54],
		"ge": [43.5, 42],
		"gg": [-2.58333333, 49.46666666],
		"gh": [-2, 8],
		"gi": [-5.35, 36.13333333],
		"gn": [-10, 11],
		"gp": [-61.583333, 16.25],
		"gm": [-16.56666666, 13.46666666],
		"gw": [-15, 12],
		"gq": [10, 2],
		"gr": [22, 39],
		"gd": [-61.66666666, 12.11666666],
		"gl": [-40, 72],
		"gt": [-90.25, 15.5],
		"gf": [-53, 4],
		"gu": [144.78333333, 13.46666666],
		"gy": [-59, 5],
		"hk": [114.188, 22.267],
		"hm": [72.51666666, -53.1],
		"hn": [-86.5, 15],
		"hr": [15.5, 45.16666666],
		"ht": [-72.41666666, 19],
		"hu": [20, 47],
		"id": [120, -5],
		"im": [-4.5, 54.25],
		"in": [77, 20],
		"io": [71.5, -6],
		"ie": [-8, 53],
		"ir": [53, 32],
		"iq": [44, 33],
		"is": [-18, 65],
		"il": [35.13, 31.47],
		"it": [12.83333333, 42.83333333],
		"jm": [-77.5, 18.25],
		"je": [-2.16666666, 49.25],
		"jo": [36, 31],
		"jp": [138, 36],
		"kz": [68, 48],
		"ke": [38, 1],
		"kg": [75, 41],
		"kh": [105, 13],
		"ki": [173, 1.41666666],
		"kn": [-62.75, 17.33333333],
		"kr": [127.5, 37],
		"xk": [21.166667, 42.666667],
		"kw": [45.75, 29.5],
		"la": [105, 18],
		"lb": [35.83333333, 33.83333333],
		"lr": [-9.5, 6.5],
		"ly": [17, 25],
		"lc": [-60.96666666, 13.88333333],
		"li": [9.53333333, 47.26666666],
		"lk": [81, 7],
		"ls": [28.5, -29.5],
		"lt": [24, 56],
		"lu": [6.16666666, 49.75],
		"lv": [25, 57],
		"mo": [113.55, 22.16666666],
		"mf": [-63.95, 18.08333333],
		"ma": [-5, 32],
		"mc": [7.4, 43.73333333],
		"md": [29, 47],
		"mg": [47, -20],
		"mv": [73, 3.25],
		"mx": [-102, 23],
		"mh": [168, 9],
		"mk": [22, 41.83333333],
		"ml": [-4, 17],
		"mt": [14.58333333, 35.83333333],
		"mm": [98, 22],
		"me": [19.3, 42.5],
		"mn": [105, 46],
		"mp": [145.75, 15.2],
		"mz": [35, -18.25],
		"mr": [-12, 20],
		"ms": [-62.2, 16.75],
		"mq": [-61, 14.666667],
		"mu": [57.55, -20.28333333],
		"mw": [34, -13.5],
		"my": [112.5, 2.5],
		"yt": [45.16666666, -12.83333333],
		"na": [17, -22],
		"nc": [165.5, -21.5],
		"ne": [8, 16],
		"nf": [167.95, -29.03333333],
		"ng": [8, 10],
		"ni": [-85, 13],
		"nu": [-169.86666666, -19.03333333],
		"nl": [5.75, 52.5],
		"no": [10, 62],
		"np": [84, 28],
		"nr": [166.91666666, -.53333333],
		"nz": [174, -41],
		"om": [57, 21],
		"pk": [70, 30],
		"pa": [-80, 9],
		"pn": [-130.1, -25.06666666],
		"pe": [-76, -10],
		"ph": [122, 13],
		"pw": [134.5, 7.5],
		"pg": [147, -6],
		"pl": [20, 52],
		"pr": [-66.5, 18.25],
		"kp": [127, 40],
		"pt": [-8, 39.5],
		"py": [-58, -23],
		"ps": [35.2, 31.9],
		"pf": [-140, -15],
		"qa": [51.25, 25.5],
		"re": [55.5, -21.15],
		"ro": [25, 46],
		"ru": [100, 60],
		"rw": [30, -2],
		"sa": [45, 25],
		"sd": [30, 15],
		"sn": [-14, 14],
		"sg": [103.8, 1.36666666],
		"gs": [-37, -54.5],
		"sj": [20, 78],
		"sb": [159, -8],
		"sl": [-11.5, 8.5],
		"sv": [-88.91666666, 13.83333333],
		"sm": [12.41666666, 43.76666666],
		"so": [49, 10],
		"pm": [-56.33333333, 46.83333333],
		"rs": [21, 44],
		"ss": [30, 7],
		"st": [7, 1],
		"sr": [-56, 4],
		"sk": [19.5, 48.66666666],
		"si": [14.81666666, 46.11666666],
		"se": [15, 62],
		"sz": [31.5, -26.5],
		"sx": [-63.05, 18.033333],
		"sc": [55.66666666, -4.58333333],
		"sy": [38, 35],
		"tc": [-71.58333333, 21.75],
		"td": [19, 15],
		"tg": [1.16666666, 8],
		"th": [100, 15],
		"tj": [71, 39],
		"tk": [-172, -9],
		"tm": [60, 40],
		"tl": [125.91666666, -8.83333333],
		"to": [-175, -20],
		"tt": [-61, 11],
		"tn": [9, 34],
		"tr": [35, 39],
		"tv": [178, -8],
		"tw": [121, 23.5],
		"tz": [35, -6],
		"ug": [32, 1],
		"ua": [32, 49],
		"um": [166.633333, 19.3],
		"uy": [-56, -33],
		"us": [-97, 38],
		"uz": [64, 41],
		"va": [12.45, 41.9],
		"vc": [-61.2, 13.25],
		"ve": [-66, 8],
		"vg": [-64.62305, 18.431383],
		"vi": [-64.933333, 18.35],
		"vn": [107.83333333, 16.16666666],
		"vu": [167, -16],
		"wf": [-176.2, -13.3],
		"ws": [-172.33333333, -13.58333333],
		"ye": [48, 15],
		"za": [24, -29],
		"zm": [30, -15],
		"zw": [30, -20]
	}
};
var numeric = geo_data_default.numeric;
var centroids = geo_data_default.capital;
var numericToIso = {};
for (const [iso, n] of Object.entries(numeric)) numericToIso[n] = iso;
/** Capitals that sit far from the country centroid. [lng, lat] */
var CAPITAL = {
	us: [-77.0369, 38.9072],
	ca: [-75.6972, 45.4215],
	ru: [37.6173, 55.7558],
	cn: [116.4074, 39.9042],
	br: [-47.8825, -15.7942],
	au: [149.13, -35.2809],
	in: [77.209, 28.6139],
	kz: [71.4306, 51.1282],
	mx: [-99.1332, 19.4326],
	id: [106.8456, -6.2088],
	cd: [15.2663, -4.4419],
	za: [28.1878, -25.7461],
	ar: [-58.3816, -34.6037],
	sa: [46.6753, 24.7136],
	dz: [3.0588, 36.7538],
	ly: [13.1913, 32.8872],
	ml: [-8.0029, 12.6392],
	ne: [2.1098, 13.5116],
	td: [15.0444, 12.1348],
	ao: [13.2344, -8.8147],
	mz: [32.5732, -25.9692],
	mg: [47.5079, -18.8792],
	na: [17.0832, -22.5609],
	mn: [106.9057, 47.8864],
	gl: [-51.7216, 64.1814],
	cl: [-70.6693, -33.4489],
	pe: [-77.0428, -12.0464],
	co: [-74.0721, 4.711],
	ve: [-66.9036, 10.4806],
	bo: [-65.2627, -19.0196],
	gb: [-.1276, 51.5072],
	fr: [2.3522, 48.8566],
	es: [-3.7038, 40.4168],
	tr: [32.8597, 39.9334],
	ir: [51.389, 35.6892],
	pk: [73.0479, 33.6844],
	eg: [31.2357, 30.0444],
	ng: [7.4951, 9.0579],
	sd: [32.5599, 15.5007],
	et: [38.7469, 9.032],
	tz: [35.7516, -6.163],
	mm: [96.0785, 19.7633],
	th: [100.5018, 13.7563],
	jp: [139.6917, 35.6895],
	kr: [126.978, 37.5665],
	ua: [30.5234, 50.4501],
	se: [18.0686, 59.3293],
	no: [10.7522, 59.9139],
	fi: [24.9384, 60.1699],
	pl: [21.0122, 52.2297],
	de: [13.405, 52.52],
	it: [12.4964, 41.9028],
	ma: [-6.8498, 33.9716],
	mr: [-15.9785, 18.0735],
	eh: [-13.2033, 27.1536],
	nz: [174.7762, -41.2865],
	pg: [147.1803, -9.4438]
};
function capitalLngLat(iso) {
	return CAPITAL[iso] ?? centroids[iso] ?? null;
}
function isoFromNumeric(id) {
	if (id == null) return void 0;
	return numericToIso[String(id).padStart(3, "0")];
}
var REGION_VIEW = {
	World: {
		center: [12, 12],
		zoom: 1
	},
	Africa: {
		center: [18, 2],
		zoom: 2.15
	},
	Americas: {
		center: [-80, 8],
		zoom: 1.55
	},
	Asia: {
		center: [90, 28],
		zoom: 1.7
	},
	Europe: {
		center: [14, 52],
		zoom: 3.2
	},
	Oceania: {
		center: [150, -18],
		zoom: 2.2
	}
};
var GEO_URL = "/maps/countries-110m.json";
function WorldMap(props) {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	const byIso = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		for (const c of props.countries) m.set(c.iso, c);
		return m;
	}, [props.countries]);
	const view = REGION_VIEW[props.region ?? "World"];
	const focus = props.focusIso ? capitalLngLat(props.focusIso) : null;
	const center = focus ?? view.center;
	const zoom = focus ? 3.6 : view.zoom;
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("h-[280px] w-full animate-pulse rounded-xl bg-raised sm:h-[360px]", props.className),
		"aria-hidden": true
	});
	const interactive = props.interactive !== false;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative overflow-hidden rounded-xl border border-border bg-surface touch-none", props.className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(N, {
			projection: "geoMercator",
			projectionConfig: {
				scale: 147,
				center: [0, 16]
			},
			width: 800,
			height: 420,
			className: "h-auto w-full",
			style: {
				width: "100%",
				height: "auto"
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(y, {
				center,
				zoom,
				minZoom: 1,
				maxZoom: 8,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(A, {
					geography: GEO_URL,
					children: ({ geographies }) => geographies.map((geo) => {
						const iso = isoFromNumeric(geo.id);
						if (!iso || iso === "aq") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(C, {
							geography: geo,
							fill: "var(--color-bg)",
							stroke: "var(--color-border)",
							strokeWidth: .4,
							style: {
								default: { outline: "none" },
								hover: { outline: "none" },
								pressed: { outline: "none" }
							}
						}, geo.rsmKey);
						const known = byIso.has(iso);
						const selected = props.selectedIso === iso;
						const correct = props.correctIso === iso;
						const wrong = props.wrongIso === iso;
						const stamped = props.mastered?.has(iso);
						let fill = "var(--color-raised)";
						if (stamped) fill = "color-mix(in oklab, var(--color-sage) 38%, var(--color-raised))";
						if (selected) fill = "color-mix(in oklab, var(--color-accent) 55%, var(--color-raised))";
						if (wrong) fill = "color-mix(in oklab, var(--color-rust) 55%, var(--color-raised))";
						if (correct) fill = "color-mix(in oklab, var(--color-sage) 70%, var(--color-raised))";
						if (!known) fill = "var(--color-bg)";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(C, {
							geography: geo,
							fill,
							stroke: "var(--color-border-strong)",
							strokeWidth: .45,
							style: {
								default: { outline: "none" },
								hover: {
									outline: "none",
									fill: interactive && known ? "color-mix(in oklab, var(--color-accent) 28%, var(--color-raised))" : fill,
									cursor: interactive && known ? "pointer" : "default"
								},
								pressed: { outline: "none" }
							},
							onClick: () => {
								if (interactive && known) props.onSelect?.(iso);
							}
						}, geo.rsmKey);
					})
				}), props.showCapitals !== false && props.countries.map((c) => {
					const pos = capitalLngLat(c.iso);
					if (!pos) return null;
					const active = props.selectedIso === c.iso || props.correctIso === c.iso || props.focusIso === c.iso;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(T, {
						coordinates: pos,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							r: active ? 3.4 : 1.35,
							fill: active ? "var(--color-accent)" : "var(--color-muted)",
							stroke: "var(--color-bg)",
							strokeWidth: .6,
							style: { cursor: interactive ? "pointer" : "default" },
							onClick: () => interactive && props.onSelect?.(c.iso)
						}), active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							y: -8,
							textAnchor: "middle",
							style: {
								fontFamily: "var(--font-sans)",
								fontSize: 8,
								fill: "var(--color-fg)",
								pointerEvents: "none"
							},
							children: c.capital
						})]
					}, c.iso);
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "pointer-events-none absolute bottom-2 left-3 text-[10px] uppercase tracking-wider text-subtle",
			children: "Drag to pan · pinch or scroll to zoom"
		})]
	});
}
var TIER_LABEL = {
	1: "Household",
	2: "Familiar",
	3: "Worldly",
	4: "Specialist"
};
function Flag({ iso, className, alt }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: flagUrl(iso, 320),
		srcSet: flagSrcSet(iso),
		sizes: "(max-width: 480px) 88vw, 420px",
		alt,
		className,
		crossOrigin: "anonymous",
		loading: "eager"
	});
}
function MiniFlag({ iso, name }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: flagUrl(iso, 80),
		alt: name,
		title: name,
		width: 40,
		height: 28,
		className: "h-7 w-10 rounded-xs object-cover ring-1 ring-border",
		crossOrigin: "anonymous",
		loading: "lazy"
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1 rounded-lg bg-raised px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium uppercase tracking-wider text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-2xl tabular-nums leading-tight text-fg",
			children: value
		})]
	});
}
function Chip({ active, children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-10 rounded-md px-3 text-sm font-medium transition-[background-color,color,border-color] duration-150", active ? "bg-accent text-accent-fg" : "border border-border bg-surface text-muted hover:border-border-strong hover:text-fg"),
		children
	});
}
function MeridianApp() {
	const [screen, setScreen] = (0, import_react.useState)("menu");
	const [progress, setProgress] = (0, import_react.useState)(() => typeof window === "undefined" ? {
		version: 1,
		mastered: [],
		best: {},
		games: 0,
		correct: 0,
		asked: 0
	} : loadProgress());
	const [mode, setMode] = (0, import_react.useState)("flags");
	const [length, setLength] = (0, import_react.useState)("classic");
	const [region, setRegion] = (0, import_react.useState)("World");
	const [includeExtras, setIncludeExtras] = (0, import_react.useState)(false);
	const [maxTier, setMaxTier] = (0, import_react.useState)(4);
	const [answerStyle, setAnswerStyle] = (0, import_react.useState)("write");
	const [questions, setQuestions] = (0, import_react.useState)([]);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [score, setScore] = (0, import_react.useState)(0);
	const [lives, setLives] = (0, import_react.useState)(3);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [hits, setHits] = (0, import_react.useState)([]);
	const [misses, setMisses] = (0, import_react.useState)([]);
	const [locked, setLocked] = (0, import_react.useState)(false);
	const pool = (0, import_react.useMemo)(() => poolFor({
		includeExtras,
		region
	}), [includeExtras, region]);
	const config = {
		mode,
		length,
		region,
		includeExtras,
		maxTier,
		answerStyle
	};
	const start = (0, import_react.useCallback)(() => {
		const qs = buildRound(pool, config);
		if (qs.length < 4) return;
		setQuestions(qs);
		setIndex(0);
		setScore(0);
		setLives(3);
		setPicked(null);
		setHits([]);
		setMisses([]);
		setLocked(false);
		setScreen("play");
	}, [pool, config]);
	const finish = (0, import_react.useCallback)((finalScore, asked, finalHits) => {
		const next = recordRound({
			key: roundKey(mode, length, region, includeExtras, maxTier) + `|${answerStyle}`,
			score: finalScore,
			asked,
			hits: finalHits
		});
		setProgress(next);
		setScreen("results");
	}, [
		mode,
		length,
		region,
		includeExtras,
		maxTier,
		answerStyle
	]);
	const current = questions[index];
	const total = questions.length;
	const isSurvival = length === "survival";
	const choose = (option) => {
		if (!current || locked) return;
		setLocked(true);
		setPicked(option);
		const correct = current.kind === "map" || answerStyle === "choice" ? option === current.answer : gradeWritten(option, current);
		const nextScore = score + (correct ? 1 : 0);
		const nextHits = correct ? [...hits, current.country.iso] : hits;
		const nextMisses = correct ? misses : [...misses, {
			country: current.country,
			kind: current.kind,
			picked: option,
			answer: current.answer
		}];
		const nextLives = correct ? lives : lives - 1;
		if (correct) setHits(nextHits);
		else {
			setMisses(nextMisses);
			setLives(nextLives);
		}
		setScore(nextScore);
		window.setTimeout(() => {
			if (index + 1 >= total || isSurvival && !correct && nextLives <= 0) {
				finish(nextScore, index + 1, nextHits);
				return;
			}
			setIndex((i) => i + 1);
			setPicked(null);
			setLocked(false);
		}, isSurvival && !correct && nextLives <= 0 ? 1100 : 1100);
	};
	(0, import_react.useEffect)(() => {
		if (screen !== "play" || answerStyle !== "choice" || current?.kind === "map") return;
		const onKey = (e) => {
			if (e.key >= "1" && e.key <= "4") {
				const opt = current?.options[Number(e.key) - 1];
				if (opt) choose(opt);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	const atlasList = includeExtras ? COUNTRIES : CORE_COUNTRIES;
	const masteredSet = (0, import_react.useMemo)(() => new Set(progress.mastered), [progress.mastered]);
	const accuracy = progress.asked ? Math.round(progress.correct / progress.asked * 100) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh overflow-x-hidden bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"aria-hidden": true,
			className: "pointer-events-none absolute inset-0",
			style: { background: "radial-gradient(1200px 500px at 50% -10%, color-mix(in oklab, var(--color-sage) 14%, transparent), transparent 70%)" }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex min-h-dvh w-full max-w-5xl flex-col px-4 pb-10 pt-6 sm:px-6",
			children: [
				screen === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
					mode,
					setMode,
					length,
					setLength,
					region,
					setRegion,
					includeExtras,
					setIncludeExtras,
					maxTier,
					setMaxTier,
					answerStyle,
					setAnswerStyle,
					poolSize: pool.filter((c) => c.tier <= maxTier).length,
					progress,
					accuracy,
					onStart: start,
					onAtlas: () => setScreen("atlas")
				}),
				screen === "play" && current && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
					current,
					countries: pool,
					index,
					total: isSurvival ? Math.max(index + 1, score + (3 - lives) + 1) : total,
					showTotal: !isSurvival,
					score,
					lives,
					isSurvival,
					picked,
					locked,
					answerStyle,
					region,
					onChoose: choose,
					onQuit: () => setScreen("menu")
				}),
				screen === "results" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Results, {
					score,
					asked: isSurvival ? score + misses.length : questions.length ? Math.min(index + 1, questions.length) : score + misses.length,
					misses,
					countries: pool,
					region,
					onAgain: start,
					onMenu: () => setScreen("menu"),
					onAtlas: () => setScreen("atlas")
				}),
				screen === "atlas" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Atlas, {
					countries: atlasList,
					mastered: masteredSet,
					onBack: () => setScreen("menu")
				})
			]
		})]
	});
}
function Menu(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rise-in flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.22em] text-muted",
						children: "World atlas quiz"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl font-medium tracking-tight sm:text-5xl",
						children: "Meridian"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 max-w-md text-sm text-muted",
						children: [CORE_COUNTRIES.length, " UN member states, plus observers and territories if you want the full map."]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, {
					className: "mt-2 size-8 text-sage",
					strokeWidth: 1.4,
					"aria-hidden": true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise-in rise-in-1 mt-8 grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Rounds",
						value: String(props.progress.games)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Accuracy",
						value: props.progress.asked ? `${props.accuracy}%` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Stamped",
						value: `${props.progress.mastered.length}`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise-in rise-in-2 mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted",
					children: "Subject"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3",
					children: Object.keys(MODE_COPY).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => props.setMode(m),
						className: cn("rounded-xl border p-3 text-left transition-[background-color,border-color] duration-150", props.mode === m ? "border-accent bg-raised" : "border-border bg-surface hover:border-border-strong"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sage",
								children: [
									m === "flags" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Earth, { className: "size-4" }),
									m === "capitals" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4" }),
									m === "reverse" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-4" }),
									m === "map" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Map$1, { className: "size-4" }),
									m === "mixed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-4" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 text-sm font-medium text-fg",
								children: MODE_COPY[m].title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-xs text-muted",
								children: MODE_COPY[m].blurb
							})
						]
					}, m))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise-in rise-in-3 mt-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted",
					children: "How you answer"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => props.setAnswerStyle("write"),
						className: cn("rounded-xl border p-3 text-left transition-[background-color,border-color] duration-150", props.answerStyle === "write" ? "border-accent bg-raised" : "border-border bg-surface hover:border-border-strong"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Keyboard, { className: "size-4 text-sage" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 text-sm font-medium",
								children: "Write it"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-xs text-muted",
								children: "Type the country or capital. Short names count."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => props.setAnswerStyle("choice"),
						className: cn("rounded-xl border p-3 text-left transition-[background-color,border-color] duration-150", props.answerStyle === "choice" ? "border-accent bg-raised" : "border-border bg-surface hover:border-border-strong"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-4 text-sage" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 text-sm font-medium",
								children: "Multiple choice"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-xs text-muted",
								children: "Four options. Keys 1–4 on desktop."
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise-in rise-in-3 mt-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted",
					children: "Length"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: Object.keys(LENGTH_COPY).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: props.length === l,
						onClick: () => props.setLength(l),
						children: LENGTH_COPY[l].title
					}, l))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise-in rise-in-4 mt-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted",
						children: "Scope"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							active: props.region === "World",
							onClick: () => props.setRegion("World"),
							children: "World"
						}), REGIONS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							active: props.region === r,
							onClick: () => props.setRegion(r),
							children: r
						}, r))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [
							1,
							2,
							3,
							4
						].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							active: props.maxTier === t,
							onClick: () => props.setMaxTier(t),
							children: TIER_LABEL[t]
						}, t))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							active: props.includeExtras,
							onClick: () => props.setIncludeExtras(!props.includeExtras),
							children: "Territories and observers"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm tabular-nums text-muted",
							children: [props.poolSize, " places"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise-in rise-in-5 mt-auto flex flex-col gap-3 pt-8 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "xl",
					className: "w-full sm:flex-1",
					onClick: props.onStart,
					children: "Begin round"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "xl",
					variant: "secondary",
					className: "w-full sm:w-auto",
					onClick: props.onAtlas,
					children: "Atlas"
				})]
			})
		]
	});
}
function WriteAnswer(props) {
	const [value, setValue] = (0, import_react.useState)("");
	const correct = props.picked != null && gradeWritten(props.picked, props.current);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-6 flex flex-col gap-3",
		onSubmit: (e) => {
			e.preventDefault();
			if (props.locked) return;
			props.onSubmit(value);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				autoFocus: true,
				disabled: props.locked,
				value: props.locked ? props.picked ?? "" : value,
				onChange: (e) => setValue(e.target.value),
				placeholder: props.current.kind === "capital" ? "Type the capital" : "Type the country",
				className: "h-12 rounded-md border border-border bg-surface px-4 text-base text-fg placeholder:text-subtle",
				autoCapitalize: "words",
				autoComplete: "off",
				spellCheck: false
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "lg",
					className: "flex-1",
					disabled: props.locked || !value.trim(),
					children: "Check"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "lg",
					variant: "secondary",
					disabled: props.locked,
					onClick: () => props.onSubmit(""),
					children: "Pass"
				})]
			}),
			props.locked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: cn("flex items-center gap-2 text-sm", correct ? "text-sage" : "text-rust"),
				children: [correct ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), correct ? "Correct" : `It's ${props.current.answer}`]
			})
		]
	});
}
function Play(props) {
	const { current } = props;
	const progressPct = props.showTotal ? (props.index + 1) / props.total * 100 : 100;
	const isMap = current.kind === "map";
	const pickedIso = props.countries.find((c) => c.name === props.picked)?.iso ?? null;
	const showReveal = props.locked && !isMap;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: props.onQuit,
					className: "inline-flex size-11 items-center justify-center rounded-md border border-border text-muted hover:text-fg",
					"aria-label": "Leave round",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: props.showTotal ? `${props.index + 1} / ${props.total}` : `Q${props.index + 1}`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: ["Score ", props.score]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 h-1 overflow-hidden rounded-full bg-raised",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-sage transition-[width] duration-300 ease-out",
							style: { width: `${progressPct}%` }
						})
					})]
				}),
				props.isSurvival && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1",
					"aria-label": `${props.lives} lives`,
					children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
						className: cn("size-4", i < props.lives ? "text-rust" : "text-subtle"),
						fill: i < props.lives ? "currentColor" : "none"
					}, i))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rise-in mt-8 flex flex-1 flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: current.prompt
				}),
				current.kind === "flag" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 overflow-hidden rounded-xl border border-border bg-raised shadow-soft",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, {
						iso: current.country.iso,
						alt: "Mystery flag",
						className: "mx-auto aspect-[3/2] w-full max-h-56 object-cover sm:max-h-72"
					})
				}),
				current.kind !== "flag" && current.kind !== "map" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-5 font-display text-3xl font-medium tracking-tight sm:text-4xl",
					children: current.kind === "capital" ? current.country.name : current.country.capital
				}),
				isMap && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldMap, {
						countries: props.countries,
						region: props.region,
						interactive: !props.locked,
						selectedIso: pickedIso,
						correctIso: props.locked ? current.country.iso : null,
						wrongIso: props.locked && pickedIso !== current.country.iso ? pickedIso : null,
						onSelect: (iso) => {
							const c = props.countries.find((x) => x.iso === iso);
							if (c) props.onChoose(c.name);
						}
					}), props.locked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-muted",
						children: [
							current.country.name,
							" · capital ",
							current.country.capital
						]
					})]
				}),
				!isMap && props.answerStyle === "choice" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 grid grid-cols-1 gap-2 sm:grid-cols-2",
					children: current.options.map((opt, i) => {
						const selected = props.picked === opt;
						const isAnswer = opt === current.answer;
						const show = props.picked !== null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: props.locked,
							onClick: () => props.onChoose(opt),
							className: cn("flex min-h-14 items-center gap-3 rounded-lg border px-4 py-3 text-left text-sm transition-[background-color,border-color,color] duration-150", !show && "border-border bg-surface hover:border-border-strong", show && isAnswer && "border-sage bg-sage/15 text-fg", show && selected && !isAnswer && "border-rust bg-rust/15 text-fg", show && !selected && !isAnswer && "border-border bg-surface opacity-60"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-muted",
									children: i + 1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 font-medium",
									children: opt
								}),
								show && isAnswer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-sage" }),
								show && selected && !isAnswer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4 text-rust" })
							]
						}, opt);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 hidden text-xs text-subtle sm:block",
					children: "Keys 1–4 select an answer."
				})] }) : null,
				!isMap && props.answerStyle === "write" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WriteAnswer, {
					current,
					locked: props.locked,
					picked: props.picked,
					onSubmit: props.onChoose
				}, current.id) : null,
				showReveal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldMap, {
						countries: props.countries,
						region: props.region,
						interactive: false,
						showCapitals: true,
						selectedIso: current.country.iso,
						correctIso: current.country.iso,
						focusIso: current.country.iso
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-muted",
						children: [
							current.country.name,
							" · ",
							current.country.capital
						]
					})]
				})
			]
		}, current.id)]
	});
}
function Results(props) {
	const pct = props.asked ? Math.round(props.score / props.asked * 100) : 0;
	const firstMiss = props.misses[0]?.country;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.22em] text-muted",
				children: "Round complete"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mt-2 font-display text-4xl font-medium tracking-tight",
				children: [props.score, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: [" / ", props.asked]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: [pct, "% correct. Stamped countries stay in your atlas."]
			}),
			firstMiss && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldMap, {
					countries: props.countries,
					region: props.region,
					interactive: false,
					showCapitals: true,
					selectedIso: firstMiss.iso,
					focusIso: firstMiss.iso
				})
			}),
			props.misses.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted",
					children: "Review"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-border overflow-hidden rounded-xl border border-border bg-surface",
					children: props.misses.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-3 px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniFlag, {
							iso: m.country.iso,
							name: m.country.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: m.country.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-muted",
								children: [
									"Capital ",
									m.country.capital,
									m.picked ? ` · you answered ${m.picked}` : " · passed"
								]
							})]
						})]
					}, m.country.iso + m.answer))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-auto flex flex-col gap-2 pt-8 sm:flex-row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "xl",
						className: "w-full sm:flex-1",
						onClick: props.onAgain,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Play again"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "xl",
						variant: "secondary",
						className: "w-full sm:w-auto",
						onClick: props.onAtlas,
						children: "Atlas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "xl",
						variant: "ghost",
						className: "w-full sm:w-auto",
						onClick: props.onMenu,
						children: "Menu"
					})
				]
			})
		]
	});
}
function Atlas(props) {
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [query, setQuery] = (0, import_react.useState)("");
	const list = filter === "All" ? props.countries : props.countries.filter((c) => c.region === filter);
	const done = list.filter((c) => props.mastered.has(c.iso)).length;
	const q = query.trim().toLowerCase();
	const filtered = q ? list.filter((c) => c.name.toLowerCase().includes(q) || c.capital.toLowerCase().includes(q) || c.aliases.some((a) => a.toLowerCase().includes(q))) : list;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: props.onBack,
				className: "inline-flex size-11 items-center justify-center rounded-md border border-border text-muted hover:text-fg",
				"aria-label": "Back",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-medium",
				children: "Atlas"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted tabular-nums",
				children: [
					done,
					" / ",
					list.length,
					" identified · tap a country to pin its capital"
				]
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex flex-wrap gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
				active: filter === "All",
				onClick: () => setFilter("All"),
				children: "All"
			}), REGIONS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
				active: filter === r,
				onClick: () => setFilter(r),
				children: r
			}, r))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldMap, {
				countries: list,
				region: filter === "All" ? "World" : filter,
				mastered: props.mastered,
				selectedIso: selected?.iso ?? null,
				focusIso: selected?.iso ?? null,
				onSelect: (iso) => {
					const c = props.countries.find((x) => x.iso === iso) ?? null;
					setSelected(c);
				}
			}, filter)
		}),
		selected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex items-center gap-3 rounded-xl border border-border bg-raised p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniFlag, {
					iso: selected.iso,
					name: selected.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-xl font-medium leading-tight",
						children: selected.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm text-muted",
						children: ["Capital ", selected.capital]
					})]
				}),
				props.mastered.has(selected.iso) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-sage" })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "search",
			value: query,
			onChange: (e) => setQuery(e.target.value),
			placeholder: "Search countries or capitals",
			className: "mt-5 h-11 w-full rounded-md border border-border bg-surface px-3 text-sm text-fg placeholder:text-subtle"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 grid grid-cols-1 gap-1 sm:grid-cols-2",
			children: filtered.map((c) => {
				const on = props.mastered.has(c.iso);
				const active = selected?.iso === c.iso;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setSelected(c),
					className: cn("flex w-full items-center gap-3 rounded-md px-2 py-2 text-left", active ? "bg-raised ring-1 ring-border-strong" : on ? "bg-raised/60" : "opacity-55"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniFlag, {
							iso: c.iso,
							name: c.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm font-medium",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-xs text-muted",
								children: c.capital
							})]
						}),
						on && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 shrink-0 text-sage" })
					]
				}) }, c.iso);
			})
		})
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeridianApp, {});
}
//#endregion
export { Home as component };
