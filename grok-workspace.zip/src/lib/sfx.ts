let ctx: AudioContext | null = null;

function audio(): AudioContext | null {
  if (typeof window === "undefined") return null;
  try {
    ctx ??= new AudioContext();
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

function beep(freq: number, dur: number, type: OscillatorType, gain = 0.05) {
  const ac = audio();
  if (!ac) return;
  const now = ac.currentTime;
  const osc = ac.createOscillator();
  const g = ac.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, now);
  g.gain.setValueAtTime(gain, now);
  g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
  osc.connect(g);
  g.connect(ac.destination);
  osc.start(now);
  osc.stop(now + dur);
}

export function unlockAudio() {
  audio();
}

export function playCorrect() {
  beep(660, 0.09, "sine", 0.045);
  setTimeout(() => beep(880, 0.11, "sine", 0.04), 70);
}

export function playWrong() {
  beep(180, 0.16, "triangle", 0.05);
}

export function tapHaptic() {
  try {
    navigator.vibrate?.(12);
  } catch {
    /* ignore */
  }
}
