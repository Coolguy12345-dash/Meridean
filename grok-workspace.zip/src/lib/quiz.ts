import type { Country, Region } from "./countries";

export type QuizMode = "flags" | "capitals" | "reverse" | "map" | "mixed";
export type LengthMode = "sprint" | "classic" | "marathon" | "survival";
export type AnswerStyle = "choice" | "write";

export type QuestionKind = "flag" | "capital" | "reverse" | "map";

export type Question = {
  id: string;
  kind: QuestionKind;
  prompt: string;
  country: Country;
  options: string[];
  answer: string;
};

export type RoundConfig = {
  mode: QuizMode;
  length: LengthMode;
  region: Region | "World";
  includeExtras: boolean;
  maxTier: 1 | 2 | 3 | 4;
  answerStyle: AnswerStyle;
};

export const LENGTH_COUNTS: Record<Exclude<LengthMode, "survival">, number> = {
  sprint: 10,
  classic: 20,
  marathon: 50,
};

export const SURVIVAL_LIVES = 3;

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function pickKind(mode: QuizMode): QuestionKind {
  if (mode === "flags") return "flag";
  if (mode === "capitals") return "capital";
  if (mode === "reverse") return "reverse";
  if (mode === "map") return "map";
  const roll = Math.random();
  if (roll < 0.28) return "flag";
  if (roll < 0.5) return "capital";
  if (roll < 0.7) return "reverse";
  return "map";
}

function distractors(correct: Country, pool: Country[], field: "name" | "capital", n: number): string[] {
  const same = pool.filter((c) => c.iso !== correct.iso && c.region === correct.region);
  const rest = pool.filter((c) => c.iso !== correct.iso && c.region !== correct.region);
  const chosen: Country[] = [];
  const take = (src: Country[]) => {
    for (const c of shuffle(src)) {
      if (chosen.length >= n) break;
      const val = c[field];
      if (val === correct[field]) continue;
      if (chosen.some((x) => x[field] === val)) continue;
      chosen.push(c);
    }
  };
  take(same);
  take(rest);
  return chosen.map((c) => c[field]);
}

export function makeQuestion(pool: Country[], mode: QuizMode, used: Set<string>): Question | null {
  const unused = pool.filter((c) => !used.has(c.iso));
  const source = unused.length > 3 ? unused : pool;
  if (source.length < 4) return null;
  const country = source[Math.floor(Math.random() * source.length)]!;
  const kind = pickKind(mode);

  if (kind === "flag") {
    const opts = shuffle([country.name, ...distractors(country, pool, "name", 3)]);
    return {
      id: `${country.iso}-flag-${Math.random().toString(36).slice(2, 7)}`,
      kind,
      prompt: "Which country flies this flag?",
      country,
      options: opts,
      answer: country.name,
    };
  }

  if (kind === "capital") {
    const opts = shuffle([country.capital, ...distractors(country, pool, "capital", 3)]);
    return {
      id: `${country.iso}-cap-${Math.random().toString(36).slice(2, 7)}`,
      kind,
      prompt: `What is the capital of ${country.name}?`,
      country,
      options: opts,
      answer: country.capital,
    };
  }

  if (kind === "map") {
    const byCapital = Math.random() < 0.5;
    return {
      id: `${country.iso}-map-${Math.random().toString(36).slice(2, 7)}`,
      kind,
      prompt: byCapital
        ? `Tap the country whose capital is ${country.capital}.`
        : `Tap ${country.name} on the map.`,
      country,
      options: [],
      answer: country.name,
    };
  }

  const opts = shuffle([country.name, ...distractors(country, pool, "name", 3)]);
  return {
    id: `${country.iso}-rev-${Math.random().toString(36).slice(2, 7)}`,
    kind,
    prompt: `${country.capital} is the capital of which country?`,
    country,
    options: opts,
    answer: country.name,
  };
}

export function buildRound(pool: Country[], config: RoundConfig): Question[] {
  const filtered = pool.filter((c) => c.tier <= config.maxTier);
  const usable = filtered.length >= 8 ? filtered : pool;
  const count =
    config.length === "survival" ? Math.min(usable.length, 200) : LENGTH_COUNTS[config.length];
  const used = new Set<string>();
  const qs: Question[] = [];
  for (let i = 0; i < count; i++) {
    const q = makeQuestion(usable, config.mode, used);
    if (!q) break;
    used.add(q.country.iso);
    qs.push(q);
  }
  return qs;
}

export function acceptedAnswers(q: Question): string[] {
  if (q.kind === "capital") {
    return [q.country.capital, ...q.country.capitalAliases];
  }
  return [q.country.name, ...q.country.aliases];
}

export function foldName(s: string): string {
  return s
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/\bsaint\b/g, "st")
    .replace(/\bst\./g, "st")
    .replace(/[^a-z0-9 ]/g, " ")
    .replace(/\bthe\b/g, " ")
    .replace(/\bcity\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const row = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let prev = i - 1;
    row[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = row[j]!;
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      row[j] = Math.min(row[j]! + 1, row[j - 1]! + 1, prev + cost);
      prev = tmp;
    }
  }
  return row[b.length]!;
}

function closeEnough(typed: string, target: string): boolean {
  if (typed === target) return true;
  if (!typed || !target) return false;
  if (target.startsWith(typed) && typed.length >= Math.max(6, Math.ceil(target.length * 0.7))) return true;
  const dist = levenshtein(typed, target);
  if (target.length >= 12) return dist <= 2;
  if (target.length >= 5) return dist <= 1;
  return false;
}

export function gradeWritten(input: string, q: Question): boolean {
  const typed = foldName(input);
  if (!typed) return false;
  return acceptedAnswers(q).some((a) => closeEnough(typed, foldName(a)));
}

export const MODE_COPY: Record<QuizMode, { title: string; blurb: string }> = {
  flags: { title: "Flags", blurb: "Match the banner to the nation." },
  capitals: { title: "Capitals", blurb: "Name the seat of government." },
  reverse: { title: "From the capital", blurb: "A city is given. Find the country." },
  map: { title: "Map", blurb: "Tap the country. Capitals light up." },
  mixed: { title: "Mixed atlas", blurb: "Flags, capitals, writing, and the map." },
};

export const LENGTH_COPY: Record<LengthMode, { title: string; blurb: string }> = {
  sprint: { title: "Sprint · 10", blurb: "Ten questions" },
  classic: { title: "Classic · 20", blurb: "Twenty questions" },
  marathon: { title: "Marathon · 50", blurb: "Fifty questions" },
  survival: { title: "Survival", blurb: "Three misses and you are out" },
};
