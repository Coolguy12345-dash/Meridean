import type { Country, Region } from "./countries";
import { capitalLngLat } from "./geo";

export type QuizMode = "flags" | "capitals" | "cities" | "reverse" | "map" | "neighbors" | "mixed";
export type LengthMode = "sprint" | "classic" | "marathon" | "survival" | "blitz";
export type AnswerStyle = "choice" | "write";

export type QuestionKind = "flag" | "capital" | "city" | "reverse" | "map" | "neighbor";

export type Question = {
  id: string;
  kind: QuestionKind;
  prompt: string;
  country: Country;
  options: string[];
  answer: string;
  city?: string;
};

export type RoundConfig = {
  mode: QuizMode;
  length: LengthMode;
  region: Region | "World";
  includeExtras: boolean;
  maxTier: 1 | 2 | 3 | 4;
  answerStyle: AnswerStyle;
  preferIsos?: string[];
  seed?: string;
};

export const LENGTH_COUNTS: Record<Exclude<LengthMode, "survival">, number> = {
  sprint: 10,
  classic: 20,
  marathon: 50,
  blitz: 15,
};

export const SURVIVAL_LIVES = 3;
export const BLITZ_SECONDS = 12;

type Rng = () => number;

function mulberry32(seed: number): Rng {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashSeed(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function shuffle<T>(arr: T[], rng: Rng = Math.random): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function haversine(a: [number, number], b: [number, number]) {
  const rad = (x: number) => (x * Math.PI) / 180;
  const dLat = rad(b[1] - a[1]);
  const dLon = rad(b[0] - a[0]);
  const la1 = rad(a[1]);
  const la2 = rad(b[1]);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dLon / 2) ** 2;
  return 2 * 6371 * Math.asin(Math.min(1, Math.sqrt(h)));
}

export function nearestCountries(country: Country, pool: Country[], n = 8): Country[] {
  const pos = capitalLngLat(country.iso);
  return pool
    .filter((c) => c.iso !== country.iso)
    .map((c) => {
      const p = capitalLngLat(c.iso);
      return { c, d: pos && p ? haversine(pos, p) : 1e9 };
    })
    .sort((a, b) => a.d - b.d)
    .slice(0, n)
    .map((x) => x.c);
}

function pickKind(mode: QuizMode, rng: Rng): QuestionKind {
  if (mode === "flags") return "flag";
  if (mode === "capitals") return "capital";
  if (mode === "cities") return "city";
  if (mode === "reverse") return "reverse";
  if (mode === "map") return "map";
  if (mode === "neighbors") return "neighbor";
  const roll = rng();
  if (roll < 0.18) return "flag";
  if (roll < 0.34) return "capital";
  if (roll < 0.5) return "city";
  if (roll < 0.62) return "reverse";
  if (roll < 0.82) return "map";
  return "neighbor";
}

function distractors(
  correct: Country,
  pool: Country[],
  field: "name" | "capital",
  n: number,
  rng: Rng,
): string[] {
  const same = pool.filter((c) => c.iso !== correct.iso && c.region === correct.region);
  const rest = pool.filter((c) => c.iso !== correct.iso && c.region !== correct.region);
  const chosen: Country[] = [];
  const take = (src: Country[]) => {
    for (const c of shuffle(src, rng)) {
      if (chosen.length >= n) break;
      const val = c[field];
      if (val === correct[field]) continue;
      if (chosen.some((x) => x[field] === val)) continue;
      chosen.push(c);
    }
  };
  take(same);
  take(rest);
  return chosen.map((c) => c[field]);
}

export function makeQuestion(pool: Country[], mode: QuizMode, used: Set<string>, rng: Rng = Math.random): Question | null {
  const unused = pool.filter((c) => !used.has(c.iso));
  const source = unused.length > 3 ? unused : pool;
  if (source.length < 4) return null;
  let country = source[Math.floor(rng() * source.length)]!;
  const kind = pickKind(mode, rng);

  if (kind === "city") {
    const withCities = source.filter((c) => c.cities.length > 0);
    const cityPool = withCities.length ? withCities : pool.filter((c) => c.cities.length > 0);
    if (!cityPool.length) return makeQuestion(pool, "capitals", used, rng);
    country = cityPool[Math.floor(rng() * cityPool.length)]!;
    const city = country.cities[Math.floor(rng() * country.cities.length)]!;
    const opts = shuffle([country.name, ...distractors(country, pool, "name", 3, rng)], rng);
    return {
      id: `${country.iso}-city-${Math.floor(rng() * 1e9)}`,
      kind,
      prompt: `${city} is a major city in which country?`,
      country,
      options: opts,
      answer: country.name,
      city,
    };
  }

  if (kind === "flag") {
    const opts = shuffle([country.name, ...distractors(country, pool, "name", 3, rng)], rng);
    return {
      id: `${country.iso}-flag-${Math.floor(rng() * 1e9)}`,
      kind,
      prompt: "Which country flies this flag?",
      country,
      options: opts,
      answer: country.name,
    };
  }

  if (kind === "capital") {
    const opts = shuffle([country.capital, ...distractors(country, pool, "capital", 3, rng)], rng);
    return {
      id: `${country.iso}-cap-${Math.floor(rng() * 1e9)}`,
      kind,
      prompt: `What is the capital of ${country.name}?`,
      country,
      options: opts,
      answer: country.capital,
    };
  }

  if (kind === "map") {
    const byCity = country.cities.length > 0 && rng() < 0.33;
    const city = byCity ? country.cities[Math.floor(rng() * country.cities.length)] : null;
    return {
      id: `${country.iso}-map-${Math.floor(rng() * 1e9)}`,
      kind,
      prompt: city
        ? `Tap the country of ${city}.`
        : rng() < 0.5
          ? `Tap the country whose capital is ${country.capital}.`
          : `Tap ${country.name} on the map.`,
      country,
      options: [],
      answer: country.name,
      city: city ?? undefined,
    };
  }

  if (kind === "neighbor") {
    const near = nearestCountries(country, pool, 6);
    const far = pool.filter((c) => c.iso !== country.iso && !near.some((n) => n.iso === c.iso));
    const neighbor = near[0];
    if (!neighbor || far.length < 3) {
      return makeQuestion(pool, "flags", used, rng);
    }
    const wrong = shuffle(far, rng).slice(0, 3).map((c) => c.name);
    const opts = shuffle([neighbor.name, ...wrong], rng);
    return {
      id: `${country.iso}-nbr-${Math.floor(rng() * 1e9)}`,
      kind,
      prompt: `Which of these borders or sits nearest to ${country.name}?`,
      country,
      options: opts,
      answer: neighbor.name,
    };
  }

  const opts = shuffle([country.name, ...distractors(country, pool, "name", 3, rng)], rng);
  return {
    id: `${country.iso}-rev-${Math.floor(rng() * 1e9)}`,
    kind,
    prompt: `${country.capital} is the capital of which country?`,
    country,
    options: opts,
    answer: country.name,
  };
}

export function buildRound(pool: Country[], config: RoundConfig): Question[] {
  const rng = config.seed ? mulberry32(hashSeed(config.seed)) : Math.random;
  const filtered = pool.filter((c) => c.tier <= config.maxTier);
  let usable = filtered.length >= 8 ? filtered : pool;
  if (config.mode === "cities") {
    const withCities = usable.filter((c) => c.cities.length > 0);
    if (withCities.length >= 8) usable = withCities;
  }
  if (config.preferIsos?.length) {
    const prefer = new Set(config.preferIsos);
    const weak = usable.filter((c) => prefer.has(c.iso));
    if (weak.length >= 4) usable = weak.length >= 8 ? weak : [...weak, ...usable.filter((c) => !prefer.has(c.iso))];
  }
  const count =
    config.length === "survival" ? Math.min(usable.length, 200) : LENGTH_COUNTS[config.length];
  const used = new Set<string>();
  const qs: Question[] = [];
  const preferQueue = config.preferIsos ? [...config.preferIsos] : [];
  for (let i = 0; i < count; i++) {
    let source = usable;
    if (preferQueue.length) {
      const iso = preferQueue.shift()!;
      const hit = usable.find((c) => c.iso === iso);
      if (hit && !used.has(hit.iso)) source = [hit, ...usable.filter((c) => c.iso !== hit.iso)];
    }
    const q = makeQuestion(source, config.mode, used, rng);
    if (!q) break;
    used.add(q.country.iso);
    qs.push(q);
  }
  return qs;
}

export function acceptedAnswers(q: Question): string[] {
  if (q.kind === "capital") {
    return [q.country.capital, ...q.country.capitalAliases];
  }
  if (q.kind === "neighbor") return [q.answer];
  return [q.country.name, ...q.country.aliases];
}

export function foldName(s: string): string {
  return s
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/\bsaint\b/g, "st")
    .replace(/\bst\./g, "st")
    .replace(/[^a-z0-9 ]/g, " ")
    .replace(/\bthe\b/g, " ")
    .replace(/\bcity\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const row = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let prev = i - 1;
    row[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = row[j]!;
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      row[j] = Math.min(row[j]! + 1, row[j - 1]! + 1, prev + cost);
      prev = tmp;
    }
  }
  return row[b.length]!;
}

function closeEnough(typed: string, target: string): boolean {
  if (typed === target) return true;
  if (!typed || !target) return false;
  if (target.startsWith(typed) && typed.length >= Math.max(6, Math.ceil(target.length * 0.7))) return true;
  const dist = levenshtein(typed, target);
  if (target.length >= 12) return dist <= 2;
  if (target.length >= 5) return dist <= 1;
  return false;
}

export function gradeWritten(input: string, q: Question): boolean {
  const typed = foldName(input);
  if (!typed) return false;
  return acceptedAnswers(q).some((a) => closeEnough(typed, foldName(a)));
}

export function suggestAnswers(input: string, pool: string[], limit = 6): string[] {
  const typed = foldName(input);
  if (typed.length < 3) return [];
  const scored = pool
    .map((name) => ({ name, f: foldName(name) }))
    .filter((x) => x.f.startsWith(typed) || x.f.includes(typed))
    .sort((a, b) => a.f.indexOf(typed) - b.f.indexOf(typed) || a.f.length - b.f.length);
  const seen = new Set<string>();
  const out: string[] = [];
  for (const s of scored) {
    if (seen.has(s.name)) continue;
    seen.add(s.name);
    out.push(s.name);
    if (out.length >= limit) break;
  }
  return out;
}

export const MODE_COPY: Record<QuizMode, { title: string; blurb: string }> = {
  flags: { title: "Flags", blurb: "Match the banner to the nation." },
  capitals: { title: "Capitals", blurb: "Name the seat of government." },
  cities: { title: "Cities", blurb: "Place a major city in its country." },
  reverse: { title: "From the capital", blurb: "A city is given. Find the country." },
  map: { title: "Map", blurb: "Tap the country. The map zooms in." },
  neighbors: { title: "Neighbors", blurb: "Who shares a border, or sits nearest?" },
  mixed: { title: "Mixed atlas", blurb: "Flags, capitals, cities, map, and neighbors." },
};

export const LENGTH_COPY: Record<LengthMode, { title: string; blurb: string }> = {
  sprint: { title: "Sprint · 10", blurb: "Ten questions" },
  classic: { title: "Classic · 20", blurb: "Twenty questions" },
  marathon: { title: "Marathon · 50", blurb: "Fifty questions" },
  blitz: { title: "Blitz · 12s", blurb: "Fifteen questions, twelve seconds each" },
  survival: { title: "Survival", blurb: "Three misses and you are out" },
};
