import geo from "./geo-data.json";
import type { Region } from "./countries";

const numeric = geo.numeric as Record<string, string>;
const centroids = geo.capital as unknown as Record<string, [number, number]>;

const numericToIso: Record<string, string> = {};
for (const [iso, n] of Object.entries(numeric)) numericToIso[n] = iso;

/** Capitals that sit far from the country centroid. [lng, lat] */
const CAPITAL: Record<string, [number, number]> = {
  us: [-77.0369, 38.9072],
  ca: [-75.6972, 45.4215],
  ru: [37.6173, 55.7558],
  cn: [116.4074, 39.9042],
  br: [-47.8825, -15.7942],
  au: [149.13, -35.2809],
  in: [77.209, 28.6139],
  kz: [71.4306, 51.1282],
  mx: [-99.1332, 19.4326],
  id: [106.8456, -6.2088],
  cd: [15.2663, -4.4419],
  za: [28.1878, -25.7461],
  ar: [-58.3816, -34.6037],
  sa: [46.6753, 24.7136],
  dz: [3.0588, 36.7538],
  ly: [13.1913, 32.8872],
  ml: [-8.0029, 12.6392],
  ne: [2.1098, 13.5116],
  td: [15.0444, 12.1348],
  ao: [13.2344, -8.8147],
  mz: [32.5732, -25.9692],
  mg: [47.5079, -18.8792],
  na: [17.0832, -22.5609],
  mn: [106.9057, 47.8864],
  gl: [-51.7216, 64.1814],
  cl: [-70.6693, -33.4489],
  pe: [-77.0428, -12.0464],
  co: [-74.0721, 4.711],
  ve: [-66.9036, 10.4806],
  bo: [-65.2627, -19.0196],
  gb: [-0.1276, 51.5072],
  fr: [2.3522, 48.8566],
  es: [-3.7038, 40.4168],
  tr: [32.8597, 39.9334],
  ir: [51.389, 35.6892],
  pk: [73.0479, 33.6844],
  eg: [31.2357, 30.0444],
  ng: [7.4951, 9.0579],
  sd: [32.5599, 15.5007],
  et: [38.7469, 9.032],
  tz: [35.7516, -6.163],
  mm: [96.0785, 19.7633],
  th: [100.5018, 13.7563],
  jp: [139.6917, 35.6895],
  kr: [126.978, 37.5665],
  ua: [30.5234, 50.4501],
  se: [18.0686, 59.3293],
  no: [10.7522, 59.9139],
  fi: [24.9384, 60.1699],
  pl: [21.0122, 52.2297],
  de: [13.405, 52.52],
  it: [12.4964, 41.9028],
  ma: [-6.8498, 33.9716],
  mr: [-15.9785, 18.0735],
  eh: [-13.2033, 27.1536],
  nz: [174.7762, -41.2865],
  pg: [147.1803, -9.4438],
};

export function capitalLngLat(iso: string): [number, number] | null {
  return CAPITAL[iso] ?? centroids[iso] ?? null;
}

export function isoFromNumeric(id: string | number | undefined): string | undefined {
  if (id == null) return undefined;
  return numericToIso[String(id).padStart(3, "0")];
}

export function numericFromIso(iso: string): string | undefined {
  return numeric[iso];
}

export function focusZoomFor(iso: string): number {
  const tiny = new Set([
    "ad", "ag", "ai", "al", "am", "aw", "bb", "bh", "bl", "bm", "bn", "bq", "bt", "cv", "cw",
    "cy", "dm", "ee", "fk", "fo", "gd", "gg", "gi", "gm", "gu", "hk", "im", "je", "ki", "km",
    "kn", "kw", "lc", "li", "ls", "lu", "lv", "mc", "md", "me", "mh", "mk", "mo", "mp", "ms",
    "mt", "mu", "mv", "nc", "nr", "nu", "pw", "qa", "rw", "sc", "sg", "sm", "sr", "st", "sx",
    "sz", "tk", "tl", "to", "tt", "tv", "va", "vc", "vg", "vi", "vu", "ws", "xk",
  ]);
  if (tiny.has(iso)) return 6.2;
  const mid = new Set(["at", "az", "be", "bg", "ba", "by", "ch", "cz", "dk", "ge", "gr", "hr", "hu", "ie", "il", "jo", "kr", "lb", "lt", "nl", "np", "nz", "pt", "rs", "si", "sk", "tw", "uy"]);
  if (mid.has(iso)) return 4.4;
  return 3.2;
}

export const REGION_VIEW: Record<Region | "World", { center: [number, number]; zoom: number }> = {
  World: { center: [12, 12], zoom: 1 },
  Africa: { center: [18, 2], zoom: 2.15 },
  Americas: { center: [-80, 8], zoom: 1.55 },
  Asia: { center: [90, 28], zoom: 1.7 },
  Europe: { center: [14, 52], zoom: 3.2 },
  Oceania: { center: [150, -18], zoom: 2.2 },
};
