const KEY = "meridian-progress-v1";
const VERSION = 2;
export const MASTER_HITS = 3;

export type Progress = {
  version: number;
  mastered: string[];
  hits: Record<string, number>;
  misses: Record<string, number>;
  best: Record<string, number>;
  games: number;
  correct: number;
  asked: number;
  daily?: { date: string; score: number; asked: number };
  sound: boolean;
};

const empty: Progress = {
  version: VERSION,
  mastered: [],
  hits: {},
  misses: {},
  best: {},
  games: 0,
  correct: 0,
  asked: 0,
  sound: true,
};

function migrate(raw: Partial<Progress> & { mastered?: string[] }): Progress {
  const hits = raw.hits && typeof raw.hits === "object" ? { ...raw.hits } : {};
  const mastered = Array.isArray(raw.mastered) ? raw.mastered : [];
  if (!raw.hits) {
    for (const iso of mastered) hits[iso] = MASTER_HITS;
  }
  return {
    ...empty,
    ...raw,
    version: VERSION,
    mastered,
    hits,
    misses: raw.misses && typeof raw.misses === "object" ? raw.misses : {},
    best: raw.best && typeof raw.best === "object" ? raw.best : {},
    games: Number(raw.games) || 0,
    correct: Number(raw.correct) || 0,
    asked: Number(raw.asked) || 0,
    daily: raw.daily,
    sound: raw.sound !== false,
  };
}

function read(): Progress {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...empty, mastered: [], hits: {}, misses: {}, best: {} };
    return migrate(JSON.parse(raw) as Partial<Progress>);
  } catch {
    return { ...empty, mastered: [], hits: {}, misses: {}, best: {} };
  }
}

function write(p: Progress) {
  try {
    localStorage.setItem(KEY, JSON.stringify(p));
  } catch {
    /* private mode */
  }
}

export function loadProgress(): Progress {
  if (typeof window === "undefined") {
    return { ...empty, mastered: [], hits: {}, misses: {}, best: {} };
  }
  return read();
}

export function todayKey(d = new Date()) {
  return d.toISOString().slice(0, 10);
}

export function recordRound(opts: {
  key: string;
  score: number;
  asked: number;
  hits: string[];
  missIsos: string[];
  daily?: boolean;
}): Progress {
  const p = read();
  p.games += 1;
  p.correct += opts.score;
  p.asked += opts.asked;
  const hitSet = new Set(opts.hits);
  for (const iso of opts.hits) {
    p.hits[iso] = (p.hits[iso] ?? 0) + 1;
    if (p.hits[iso]! >= MASTER_HITS && !p.mastered.includes(iso)) p.mastered.push(iso);
  }
  for (const iso of opts.missIsos) {
    if (hitSet.has(iso)) continue;
    p.misses[iso] = (p.misses[iso] ?? 0) + 1;
    p.hits[iso] = 0;
    p.mastered = p.mastered.filter((x) => x !== iso);
  }
  const prev = p.best[opts.key] ?? 0;
  if (opts.score > prev) p.best[opts.key] = opts.score;
  if (opts.daily) {
    p.daily = { date: todayKey(), score: opts.score, asked: opts.asked };
  }
  write(p);
  return p;
}

export function setSound(on: boolean): Progress {
  const p = read();
  p.sound = on;
  write(p);
  return p;
}

export function roundKey(mode: string, length: string, region: string, extras: boolean, tier: number) {
  return `${mode}|${length}|${region}|${extras ? "x" : "c"}|t${tier}`;
}

export function weakIsos(p: Progress, poolIsos: string[]): string[] {
  const mastered = new Set(p.mastered);
  const scored = poolIsos.map((iso) => ({
    iso,
    miss: p.misses[iso] ?? 0,
    hit: p.hits[iso] ?? 0,
    stamped: mastered.has(iso),
  }));
  const missed = scored.filter((x) => x.miss > 0).sort((a, b) => b.miss - a.miss || a.hit - b.hit);
  const inProgress = scored
    .filter((x) => x.miss === 0 && x.hit > 0 && !x.stamped)
    .sort((a, b) => a.hit - b.hit);
  const unseen = scored.filter((x) => x.hit === 0 && x.miss === 0);
  const primary = [...missed, ...inProgress];
  if (primary.length >= 4) return primary.map((x) => x.iso);
  return [...primary, ...unseen].map((x) => x.iso);
}

export function weakCount(p: Progress, poolIsos: string[]): number {
  const mastered = new Set(p.mastered);
  return poolIsos.filter((iso) => (p.misses[iso] ?? 0) > 0 || ((p.hits[iso] ?? 0) > 0 && !mastered.has(iso))).length;
}
