const KEY = "meridian-progress-v1";
const VERSION = 1;

export type Progress = {
  version: number;
  mastered: string[];
  best: Record<string, number>;
  games: number;
  correct: number;
  asked: number;
};

const empty: Progress = {
  version: VERSION,
  mastered: [],
  best: {},
  games: 0,
  correct: 0,
  asked: 0,
};

function read(): Progress {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...empty, mastered: [], best: {} };
    const parsed = JSON.parse(raw) as Partial<Progress>;
    return {
      ...empty,
      ...parsed,
      version: VERSION,
      mastered: Array.isArray(parsed.mastered) ? parsed.mastered : [],
      best: parsed.best && typeof parsed.best === "object" ? parsed.best : {},
      games: Number(parsed.games) || 0,
      correct: Number(parsed.correct) || 0,
      asked: Number(parsed.asked) || 0,
    };
  } catch {
    return { ...empty, mastered: [], best: {} };
  }
}

function write(p: Progress) {
  try {
    localStorage.setItem(KEY, JSON.stringify(p));
  } catch {
    /* private mode */
  }
}

export function loadProgress(): Progress {
  if (typeof window === "undefined") return { ...empty, mastered: [], best: {} };
  return read();
}

export function recordRound(opts: {
  key: string;
  score: number;
  asked: number;
  hits: string[];
}): Progress {
  const p = read();
  p.games += 1;
  p.correct += opts.score;
  p.asked += opts.asked;
  const set = new Set(p.mastered);
  for (const iso of opts.hits) set.add(iso);
  p.mastered = [...set];
  const prev = p.best[opts.key] ?? 0;
  if (opts.score > prev) p.best[opts.key] = opts.score;
  write(p);
  return p;
}

export function roundKey(mode: string, length: string, region: string, extras: boolean, tier: number) {
  return `${mode}|${length}|${region}|${extras ? "x" : "c"}|t${tier}`;
}
