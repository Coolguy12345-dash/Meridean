import { useEffect, useMemo, useState } from "react";
import { ComposableMap, Geographies, Geography, Marker, ZoomableGroup } from "react-simple-maps";
import type { Country, Region } from "@/lib/countries";
import { capitalLngLat, isoFromNumeric, REGION_VIEW } from "@/lib/geo";
import { cn } from "@/lib/utils";

const GEO_URL = "/maps/countries-110m.json";

type Props = {
  countries: Country[];
  selectedIso?: string | null;
  correctIso?: string | null;
  wrongIso?: string | null;
  mastered?: Set<string>;
  onSelect?: (iso: string) => void;
  interactive?: boolean;
  showCapitals?: boolean;
  region?: Region | "World";
  className?: string;
  focusIso?: string | null;
};

export function WorldMap(props: Props) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const byIso = useMemo(() => {
    const m = new Map<string, Country>();
    for (const c of props.countries) m.set(c.iso, c);
    return m;
  }, [props.countries]);

  const view = REGION_VIEW[props.region ?? "World"];
  const focus = props.focusIso ? capitalLngLat(props.focusIso) : null;
  const center = (focus ?? view.center) as [number, number];
  const zoom = focus ? 3.6 : view.zoom;

  if (!mounted) {
    return (
      <div
        className={cn("h-[280px] w-full animate-pulse rounded-xl bg-raised sm:h-[360px]", props.className)}
        aria-hidden
      />
    );
  }

  const interactive = props.interactive !== false;

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl border border-border bg-surface touch-none",
        props.className,
      )}
    >
      <ComposableMap
        projection="geoMercator"
        projectionConfig={{ scale: 147, center: [0, 16] }}
        width={800}
        height={420}
        className="h-auto w-full"
        style={{ width: "100%", height: "auto" }}
      >
        <ZoomableGroup center={center} zoom={zoom} minZoom={1} maxZoom={8}>
          <Geographies geography={GEO_URL}>
            {({ geographies }) =>
              geographies.map((geo) => {
                const iso = isoFromNumeric(geo.id as string);
                if (!iso || iso === "aq") {
                  return (
                    <Geography
                      key={geo.rsmKey}
                      geography={geo}
                      fill="var(--color-bg)"
                      stroke="var(--color-border)"
                      strokeWidth={0.4}
                      className="outline-none"
                    />
                  );
                }
                const known = byIso.has(iso);
                const selected = props.selectedIso === iso;
                const correct = props.correctIso === iso;
                const wrong = props.wrongIso === iso;
                const stamped = props.mastered?.has(iso);
                let fill = "var(--color-raised)";
                if (stamped) fill = "color-mix(in oklab, var(--color-sage) 38%, var(--color-raised))";
                if (selected) fill = "color-mix(in oklab, var(--color-accent) 55%, var(--color-raised))";
                if (wrong) fill = "color-mix(in oklab, var(--color-rust) 55%, var(--color-raised))";
                if (correct) fill = "color-mix(in oklab, var(--color-sage) 70%, var(--color-raised))";
                if (!known) fill = "var(--color-bg)";
                return (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    fill={fill}
                    stroke="var(--color-border-strong)"
                    strokeWidth={0.45}
                    className={cn(
                      "outline-none transition-[filter] duration-150",
                      interactive && known && "cursor-pointer hover:brightness-125",
                    )}
                    onClick={() => {
                      if (interactive && known) props.onSelect?.(iso);
                    }}
                  />
                );
              })
            }
          </Geographies>
          {props.showCapitals !== false &&
            props.countries.map((c) => {
              const pos = capitalLngLat(c.iso);
              if (!pos) return null;
              const active = props.selectedIso === c.iso || props.correctIso === c.iso || props.focusIso === c.iso;
              return (
                <Marker key={c.iso} coordinates={pos}>
                  <circle
                    r={active ? 3.4 : 1.35}
                    fill={active ? "var(--color-accent)" : "var(--color-muted)"}
                    stroke="var(--color-bg)"
                    strokeWidth={0.6}
                    style={{ cursor: interactive ? "pointer" : "default" }}
                    onClick={() => interactive && props.onSelect?.(c.iso)}
                  />
                  {active && (
                    <text
                      y={-8}
                      textAnchor="middle"
                      style={{
                        fontFamily: "var(--font-sans)",
                        fontSize: 8,
                        fill: "var(--color-fg)",
                        pointerEvents: "none",
                      }}
                    >
                      {c.capital}
                    </text>
                  )}
                </Marker>
              );
            })}
        </ZoomableGroup>
      </ComposableMap>
      <p className="pointer-events-none absolute bottom-2 left-3 text-[10px] uppercase tracking-wider text-subtle">
        Drag to pan · pinch or scroll to zoom
      </p>
    </div>
  );
}
