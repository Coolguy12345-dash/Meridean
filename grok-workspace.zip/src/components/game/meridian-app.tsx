import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  ArrowLeft,
  Check,
  Compass,
  Earth,
  Heart,
  Keyboard,
  Landmark,
  LayoutGrid,
  Map as MapIcon,
  RotateCcw,
  X,
} from "lucide-react";
import { CORE_COUNTRIES, COUNTRIES, flagSrcSet, flagUrl, poolFor, REGIONS, type Country, type Region } from "@/lib/countries";
import {
  buildRound,
  gradeWritten,
  LENGTH_COPY,
  MODE_COPY,
  SURVIVAL_LIVES,
  type AnswerStyle,
  type LengthMode,
  type Question,
  type QuizMode,
} from "@/lib/quiz";
import { loadProgress, recordRound, roundKey, type Progress } from "@/lib/progress";
import { Button } from "@/components/ui/button";
import { WorldMap } from "@/components/game/world-map";
import { cn } from "@/lib/utils";

type Screen = "menu" | "play" | "results" | "atlas";

const TIER_LABEL: Record<1 | 2 | 3 | 4, string> = {
  1: "Household",
  2: "Familiar",
  3: "Worldly",
  4: "Specialist",
};

function Flag({ iso, className, alt }: { iso: string; className?: string; alt: string }) {
  return (
    <img
      src={flagUrl(iso, 320)}
      srcSet={flagSrcSet(iso)}
      sizes="(max-width: 480px) 88vw, 420px"
      alt={alt}
      className={className}
      crossOrigin="anonymous"
      loading="eager"
    />
  );
}

function MiniFlag({ iso, name }: { iso: string; name: string }) {
  return (
    <img
      src={flagUrl(iso, 80)}
      alt={name}
      title={name}
      width={40}
      height={28}
      className="h-7 w-10 rounded-xs object-cover ring-1 ring-border"
      crossOrigin="anonymous"
      loading="lazy"
    />
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1 rounded-lg bg-raised px-4 py-3">
      <span className="text-xs font-medium uppercase tracking-wider text-muted">{label}</span>
      <span className="font-display text-2xl tabular-nums leading-tight text-fg">{value}</span>
    </div>
  );
}

function Chip({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-10 rounded-md px-3 text-sm font-medium transition-[background-color,color,border-color] duration-150",
        active
          ? "bg-accent text-accent-fg"
          : "border border-border bg-surface text-muted hover:border-border-strong hover:text-fg",
      )}
    >
      {children}
    </button>
  );
}

export function MeridianApp() {
  const [screen, setScreen] = useState<Screen>("menu");
  const [progress, setProgress] = useState<Progress>(() =>
    typeof window === "undefined"
      ? { version: 1, mastered: [], best: {}, games: 0, correct: 0, asked: 0 }
      : loadProgress(),
  );

  const [mode, setMode] = useState<QuizMode>("flags");
  const [length, setLength] = useState<LengthMode>("classic");
  const [region, setRegion] = useState<Region | "World">("World");
  const [includeExtras, setIncludeExtras] = useState(false);
  const [maxTier, setMaxTier] = useState<1 | 2 | 3 | 4>(4);
  const [answerStyle, setAnswerStyle] = useState<AnswerStyle>("write");

  const [questions, setQuestions] = useState<Question[]>([]);
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(SURVIVAL_LIVES);
  const [picked, setPicked] = useState<string | null>(null);
  const [hits, setHits] = useState<string[]>([]);
  const [misses, setMisses] = useState<{ country: Country; kind: string; picked: string; answer: string }[]>(
    [],
  );
  const [locked, setLocked] = useState(false);

  const pool = useMemo(
    () => poolFor({ includeExtras, region }),
    [includeExtras, region],
  );

  const config = { mode, length, region, includeExtras, maxTier, answerStyle };

  const start = useCallback(() => {
    const qs = buildRound(pool, config);
    if (qs.length < 4) return;
    setQuestions(qs);
    setIndex(0);
    setScore(0);
    setLives(SURVIVAL_LIVES);
    setPicked(null);
    setHits([]);
    setMisses([]);
    setLocked(false);
    setScreen("play");
  }, [pool, config]);

  const finish = useCallback(
    (finalScore: number, asked: number, finalHits: string[]) => {
      const key = roundKey(mode, length, region, includeExtras, maxTier) + `|${answerStyle}`;
      const next = recordRound({ key, score: finalScore, asked, hits: finalHits });
      setProgress(next);
      setScreen("results");
    },
    [mode, length, region, includeExtras, maxTier, answerStyle],
  );

  const current = questions[index];
  const total = questions.length;
  const isSurvival = length === "survival";

  const choose = (option: string) => {
    if (!current || locked) return;
    setLocked(true);
    setPicked(option);
    const correct =
      current.kind === "map" || answerStyle === "choice"
        ? option === current.answer
        : gradeWritten(option, current);
    const nextScore = score + (correct ? 1 : 0);
    const nextHits = correct ? [...hits, current.country.iso] : hits;
    const nextMisses = correct
      ? misses
      : [...misses, { country: current.country, kind: current.kind, picked: option, answer: current.answer }];
    const nextLives = correct ? lives : lives - 1;
    if (correct) setHits(nextHits);
    else {
      setMisses(nextMisses);
      setLives(nextLives);
    }
    setScore(nextScore);

    window.setTimeout(() => {
      const last = index + 1 >= total;
      const dead = isSurvival && !correct && nextLives <= 0;
      if (last || dead) {
        finish(nextScore, index + 1, nextHits);
        return;
      }
      setIndex((i) => i + 1);
      setPicked(null);
      setLocked(false);
    }, isSurvival && !correct && nextLives <= 0 ? 1100 : 1100);
  };

  useEffect(() => {
    if (screen !== "play" || answerStyle !== "choice" || current?.kind === "map") return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key >= "1" && e.key <= "4") {
        const opt = current?.options[Number(e.key) - 1];
        if (opt) choose(opt);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const atlasList = includeExtras ? COUNTRIES : CORE_COUNTRIES;
  const masteredSet = useMemo(() => new Set(progress.mastered), [progress.mastered]);
  const accuracy = progress.asked ? Math.round((progress.correct / progress.asked) * 100) : 0;

  return (
    <div className="relative min-h-dvh overflow-x-hidden bg-bg text-fg">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(1200px 500px at 50% -10%, color-mix(in oklab, var(--color-sage) 14%, transparent), transparent 70%)",
        }}
      />
      <div className="relative mx-auto flex min-h-dvh w-full max-w-5xl flex-col px-4 pb-10 pt-6 sm:px-6">
        {screen === "menu" && (
          <Menu
            mode={mode}
            setMode={setMode}
            length={length}
            setLength={setLength}
            region={region}
            setRegion={setRegion}
            includeExtras={includeExtras}
            setIncludeExtras={setIncludeExtras}
            maxTier={maxTier}
            setMaxTier={setMaxTier}
            answerStyle={answerStyle}
            setAnswerStyle={setAnswerStyle}
            poolSize={pool.filter((c) => c.tier <= maxTier).length}
            progress={progress}
            accuracy={accuracy}
            onStart={start}
            onAtlas={() => setScreen("atlas")}
          />
        )}

        {screen === "play" && current && (
          <Play
            current={current}
            countries={pool}
            index={index}
            total={isSurvival ? Math.max(index + 1, score + (SURVIVAL_LIVES - lives) + 1) : total}
            showTotal={!isSurvival}
            score={score}
            lives={lives}
            isSurvival={isSurvival}
            picked={picked}
            locked={locked}
            answerStyle={answerStyle}
            region={region}
            onChoose={choose}
            onQuit={() => setScreen("menu")}
          />
        )}

        {screen === "results" && (
          <Results
            score={score}
            asked={isSurvival ? score + misses.length : questions.length ? Math.min(index + 1, questions.length) : score + misses.length}
            misses={misses}
            countries={pool}
            region={region}
            onAgain={start}
            onMenu={() => setScreen("menu")}
            onAtlas={() => setScreen("atlas")}
          />
        )}

        {screen === "atlas" && (
          <Atlas
            countries={atlasList}
            mastered={masteredSet}
            onBack={() => setScreen("menu")}
          />
        )}
      </div>
    </div>
  );
}

function Menu(props: {
  mode: QuizMode;
  setMode: (m: QuizMode) => void;
  length: LengthMode;
  setLength: (l: LengthMode) => void;
  region: Region | "World";
  setRegion: (r: Region | "World") => void;
  includeExtras: boolean;
  setIncludeExtras: (v: boolean) => void;
  maxTier: 1 | 2 | 3 | 4;
  setMaxTier: (t: 1 | 2 | 3 | 4) => void;
  answerStyle: AnswerStyle;
  setAnswerStyle: (s: AnswerStyle) => void;
  poolSize: number;
  progress: Progress;
  accuracy: number;
  onStart: () => void;
  onAtlas: () => void;
}) {
  return (
    <div className="flex flex-1 flex-col">
      <header className="rise-in flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">World atlas quiz</p>
          <h1 className="mt-2 font-display text-4xl font-medium tracking-tight sm:text-5xl">Meridian</h1>
          <p className="mt-3 max-w-md text-sm text-muted">
            {CORE_COUNTRIES.length} UN member states, plus observers and territories if you want the full map.
          </p>
        </div>
        <Compass className="mt-2 size-8 text-sage" strokeWidth={1.4} aria-hidden />
      </header>

      <div className="rise-in rise-in-1 mt-8 grid grid-cols-3 gap-2">
        <Stat label="Rounds" value={String(props.progress.games)} />
        <Stat label="Accuracy" value={props.progress.asked ? `${props.accuracy}%` : "—"} />
        <Stat label="Stamped" value={`${props.progress.mastered.length}`} />
      </div>

      <section className="rise-in rise-in-2 mt-8">
        <h2 className="text-xs font-medium uppercase tracking-[0.18em] text-muted">Subject</h2>
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
          {(Object.keys(MODE_COPY) as QuizMode[]).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => props.setMode(m)}
              className={cn(
                "rounded-xl border p-3 text-left transition-[background-color,border-color] duration-150",
                props.mode === m
                  ? "border-accent bg-raised"
                  : "border-border bg-surface hover:border-border-strong",
              )}
            >
              <div className="text-sage">
                {m === "flags" && <Earth className="size-4" />}
                {m === "capitals" && <Landmark className="size-4" />}
                {m === "reverse" && <Compass className="size-4" />}
                {m === "map" && <MapIcon className="size-4" />}
                {m === "mixed" && <LayoutGrid className="size-4" />}
              </div>
              <div className="mt-2 text-sm font-medium text-fg">{MODE_COPY[m].title}</div>
              <div className="mt-1 text-xs text-muted">{MODE_COPY[m].blurb}</div>
            </button>
          ))}
        </div>
      </section>

      <section className="rise-in rise-in-3 mt-7">
        <h2 className="text-xs font-medium uppercase tracking-[0.18em] text-muted">How you answer</h2>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => props.setAnswerStyle("write")}
            className={cn(
              "rounded-xl border p-3 text-left transition-[background-color,border-color] duration-150",
              props.answerStyle === "write"
                ? "border-accent bg-raised"
                : "border-border bg-surface hover:border-border-strong",
            )}
          >
            <Keyboard className="size-4 text-sage" />
            <div className="mt-2 text-sm font-medium">Write it</div>
            <div className="mt-1 text-xs text-muted">Type the country or capital. Short names count.</div>
          </button>
          <button
            type="button"
            onClick={() => props.setAnswerStyle("choice")}
            className={cn(
              "rounded-xl border p-3 text-left transition-[background-color,border-color] duration-150",
              props.answerStyle === "choice"
                ? "border-accent bg-raised"
                : "border-border bg-surface hover:border-border-strong",
            )}
          >
            <LayoutGrid className="size-4 text-sage" />
            <div className="mt-2 text-sm font-medium">Multiple choice</div>
            <div className="mt-1 text-xs text-muted">Four options. Keys 1–4 on desktop.</div>
          </button>
        </div>
      </section>

      <section className="rise-in rise-in-3 mt-7">
        <h2 className="text-xs font-medium uppercase tracking-[0.18em] text-muted">Length</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {(Object.keys(LENGTH_COPY) as LengthMode[]).map((l) => (
            <Chip key={l} active={props.length === l} onClick={() => props.setLength(l)}>
              {LENGTH_COPY[l].title}
            </Chip>
          ))}
        </div>
      </section>

      <section className="rise-in rise-in-4 mt-7">
        <h2 className="text-xs font-medium uppercase tracking-[0.18em] text-muted">Scope</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          <Chip active={props.region === "World"} onClick={() => props.setRegion("World")}>
            World
          </Chip>
          {REGIONS.map((r) => (
            <Chip key={r} active={props.region === r} onClick={() => props.setRegion(r)}>
              {r}
            </Chip>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {([1, 2, 3, 4] as const).map((t) => (
            <Chip key={t} active={props.maxTier === t} onClick={() => props.setMaxTier(t)}>
              {TIER_LABEL[t]}
            </Chip>
          ))}
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <Chip active={props.includeExtras} onClick={() => props.setIncludeExtras(!props.includeExtras)}>
            Territories and observers
          </Chip>
          <span className="text-sm tabular-nums text-muted">{props.poolSize} places</span>
        </div>
      </section>

      <div className="rise-in rise-in-5 mt-auto flex flex-col gap-3 pt-8 sm:flex-row">
        <Button size="xl" className="w-full sm:flex-1" onClick={props.onStart}>
          Begin round
        </Button>
        <Button size="xl" variant="secondary" className="w-full sm:w-auto" onClick={props.onAtlas}>
          Atlas
        </Button>
      </div>
    </div>
  );
}

function WriteAnswer(props: {
  current: Question;
  locked: boolean;
  picked: string | null;
  onSubmit: (value: string) => void;
}) {
  const [value, setValue] = useState("");
  const correct = props.picked != null && gradeWritten(props.picked, props.current);
  return (
    <form
      className="mt-6 flex flex-col gap-3"
      onSubmit={(e) => {
        e.preventDefault();
        if (props.locked) return;
        props.onSubmit(value);
      }}
    >
      <input
        autoFocus
        disabled={props.locked}
        value={props.locked ? (props.picked ?? "") : value}
        onChange={(e) => setValue(e.target.value)}
        placeholder={props.current.kind === "capital" ? "Type the capital" : "Type the country"}
        className="h-12 rounded-md border border-border bg-surface px-4 text-base text-fg placeholder:text-subtle"
        autoCapitalize="words"
        autoComplete="off"
        spellCheck={false}
      />
      <div className="flex gap-2">
        <Button type="submit" size="lg" className="flex-1" disabled={props.locked || !value.trim()}>
          Check
        </Button>
        <Button type="button" size="lg" variant="secondary" disabled={props.locked} onClick={() => props.onSubmit("")}>
          Pass
        </Button>
      </div>
      {props.locked && (
        <p className={cn("flex items-center gap-2 text-sm", correct ? "text-sage" : "text-rust")}>
          {correct ? <Check className="size-4" /> : <X className="size-4" />}
          {correct ? "Correct" : `It's ${props.current.answer}`}
        </p>
      )}
    </form>
  );
}

function Play(props: {
  current: Question;
  countries: Country[];
  index: number;
  total: number;
  showTotal: boolean;
  score: number;
  lives: number;
  isSurvival: boolean;
  picked: string | null;
  locked: boolean;
  answerStyle: AnswerStyle;
  region: Region | "World";
  onChoose: (opt: string) => void;
  onQuit: () => void;
}) {
  const { current } = props;
  const progressPct = props.showTotal ? ((props.index + 1) / props.total) * 100 : 100;
  const isMap = current.kind === "map";
  const pickedIso = props.countries.find((c) => c.name === props.picked)?.iso ?? null;
  const showReveal = props.locked && !isMap;

  return (
    <div className="flex flex-1 flex-col">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={props.onQuit}
          className="inline-flex size-11 items-center justify-center rounded-md border border-border text-muted hover:text-fg"
          aria-label="Leave round"
        >
          <ArrowLeft className="size-4" />
        </button>
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between text-xs text-muted">
            <span className="tabular-nums">
              {props.showTotal ? `${props.index + 1} / ${props.total}` : `Q${props.index + 1}`}
            </span>
            <span className="tabular-nums">Score {props.score}</span>
          </div>
          <div className="mt-2 h-1 overflow-hidden rounded-full bg-raised">
            <div
              className="h-full bg-sage transition-[width] duration-300 ease-out"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>
        {props.isSurvival && (
          <div className="flex gap-1" aria-label={`${props.lives} lives`}>
            {Array.from({ length: SURVIVAL_LIVES }).map((_, i) => (
              <Heart
                key={i}
                className={cn("size-4", i < props.lives ? "text-rust" : "text-subtle")}
                fill={i < props.lives ? "currentColor" : "none"}
              />
            ))}
          </div>
        )}
      </div>

      <div key={current.id} className="rise-in mt-8 flex flex-1 flex-col">
        <p className="text-sm text-muted">{current.prompt}</p>

        {current.kind === "flag" && (
          <div className="mt-5 overflow-hidden rounded-xl border border-border bg-raised shadow-soft">
            <Flag
              iso={current.country.iso}
              alt="Mystery flag"
              className="mx-auto aspect-[3/2] w-full max-h-56 object-cover sm:max-h-72"
            />
          </div>
        )}

        {current.kind !== "flag" && current.kind !== "map" && (
          <h2 className="mt-5 font-display text-3xl font-medium tracking-tight sm:text-4xl">
            {current.kind === "capital" ? current.country.name : current.country.capital}
          </h2>
        )}

        {isMap && (
          <div className="mt-5">
            <WorldMap
              countries={props.countries}
              region={props.region}
              interactive={!props.locked}
              selectedIso={pickedIso}
              correctIso={props.locked ? current.country.iso : null}
              wrongIso={props.locked && pickedIso !== current.country.iso ? pickedIso : null}
              onSelect={(iso) => {
                const c = props.countries.find((x) => x.iso === iso);
                if (c) props.onChoose(c.name);
              }}
            />
            {props.locked && (
              <p className="mt-3 text-sm text-muted">
                {current.country.name} · capital {current.country.capital}
              </p>
            )}
          </div>
        )}

        {!isMap && props.answerStyle === "choice" ? (
          <>
            <div className="mt-6 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {current.options.map((opt, i) => {
                const selected = props.picked === opt;
                const isAnswer = opt === current.answer;
                const show = props.picked !== null;
                return (
                  <button
                    key={opt}
                    type="button"
                    disabled={props.locked}
                    onClick={() => props.onChoose(opt)}
                    className={cn(
                      "flex min-h-14 items-center gap-3 rounded-lg border px-4 py-3 text-left text-sm transition-[background-color,border-color,color] duration-150",
                      !show && "border-border bg-surface hover:border-border-strong",
                      show && isAnswer && "border-sage bg-sage/15 text-fg",
                      show && selected && !isAnswer && "border-rust bg-rust/15 text-fg",
                      show && !selected && !isAnswer && "border-border bg-surface opacity-60",
                    )}
                  >
                    <span className="font-mono text-xs text-muted">{i + 1}</span>
                    <span className="flex-1 font-medium">{opt}</span>
                    {show && isAnswer && <Check className="size-4 text-sage" />}
                    {show && selected && !isAnswer && <X className="size-4 text-rust" />}
                  </button>
                );
              })}
            </div>
            <p className="mt-4 hidden text-xs text-subtle sm:block">Keys 1–4 select an answer.</p>
          </>
        ) : null}

        {!isMap && props.answerStyle === "write" ? (
          <WriteAnswer
            key={current.id}
            current={current}
            locked={props.locked}
            picked={props.picked}
            onSubmit={props.onChoose}
          />
        ) : null}

        {showReveal && (
          <div className="mt-5">
            <WorldMap
              countries={props.countries}
              region={props.region}
              interactive={false}
              showCapitals
              selectedIso={current.country.iso}
              correctIso={current.country.iso}
              focusIso={current.country.iso}
            />
            <p className="mt-2 text-xs text-muted">
              {current.country.name} · {current.country.capital}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function Results(props: {
  score: number;
  asked: number;
  misses: { country: Country; kind: string; picked: string; answer: string }[];
  countries: Country[];
  region: Region | "World";
  onAgain: () => void;
  onMenu: () => void;
  onAtlas: () => void;
}) {
  const pct = props.asked ? Math.round((props.score / props.asked) * 100) : 0;
  const firstMiss = props.misses[0]?.country;
  return (
    <div className="flex flex-1 flex-col">
      <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">Round complete</p>
      <h2 className="mt-2 font-display text-4xl font-medium tracking-tight">
        {props.score}
        <span className="text-muted"> / {props.asked}</span>
      </h2>
      <p className="mt-2 text-sm text-muted">{pct}% correct. Stamped countries stay in your atlas.</p>

      {firstMiss && (
        <div className="mt-6">
          <WorldMap
            countries={props.countries}
            region={props.region}
            interactive={false}
            showCapitals
            selectedIso={firstMiss.iso}
            focusIso={firstMiss.iso}
          />
        </div>
      )}

      {props.misses.length > 0 && (
        <div className="mt-8">
          <h3 className="text-xs font-medium uppercase tracking-[0.18em] text-muted">Review</h3>
          <ul className="mt-3 divide-y divide-border overflow-hidden rounded-xl border border-border bg-surface">
            {props.misses.map((m) => (
              <li key={m.country.iso + m.answer} className="flex items-start gap-3 px-4 py-3">
                <MiniFlag iso={m.country.iso} name={m.country.name} />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium">{m.country.name}</div>
                  <div className="text-xs text-muted">
                    Capital {m.country.capital}
                    {m.picked ? ` · you answered ${m.picked}` : " · passed"}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-auto flex flex-col gap-2 pt-8 sm:flex-row">
        <Button size="xl" className="w-full sm:flex-1" onClick={props.onAgain}>
          <RotateCcw className="size-4" />
          Play again
        </Button>
        <Button size="xl" variant="secondary" className="w-full sm:w-auto" onClick={props.onAtlas}>
          Atlas
        </Button>
        <Button size="xl" variant="ghost" className="w-full sm:w-auto" onClick={props.onMenu}>
          Menu
        </Button>
      </div>
    </div>
  );
}

function Atlas(props: {
  countries: Country[];
  mastered: Set<string>;
  onBack: () => void;
}) {
  const [filter, setFilter] = useState<Region | "All">("All");
  const [selected, setSelected] = useState<Country | null>(null);
  const [query, setQuery] = useState("");
  const list = filter === "All" ? props.countries : props.countries.filter((c) => c.region === filter);
  const done = list.filter((c) => props.mastered.has(c.iso)).length;
  const q = query.trim().toLowerCase();
  const filtered = q
    ? list.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.capital.toLowerCase().includes(q) ||
          c.aliases.some((a) => a.toLowerCase().includes(q)),
      )
    : list;

  return (
    <div>
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={props.onBack}
          className="inline-flex size-11 items-center justify-center rounded-md border border-border text-muted hover:text-fg"
          aria-label="Back"
        >
          <ArrowLeft className="size-4" />
        </button>
        <div>
          <h2 className="font-display text-2xl font-medium">Atlas</h2>
          <p className="text-sm text-muted tabular-nums">
            {done} / {list.length} identified · tap a country to pin its capital
          </p>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-2">
        <Chip active={filter === "All"} onClick={() => setFilter("All")}>
          All
        </Chip>
        {REGIONS.map((r) => (
          <Chip key={r} active={filter === r} onClick={() => setFilter(r)}>
            {r}
          </Chip>
        ))}
      </div>

      <div className="mt-4">
        <WorldMap
          key={filter}
          countries={list}
          region={filter === "All" ? "World" : filter}
          mastered={props.mastered}
          selectedIso={selected?.iso ?? null}
          focusIso={selected?.iso ?? null}
          onSelect={(iso) => {
            const c = props.countries.find((x) => x.iso === iso) ?? null;
            setSelected(c);
          }}
        />
      </div>

      {selected && (
        <div className="mt-4 flex items-center gap-3 rounded-xl border border-border bg-raised p-4">
          <MiniFlag iso={selected.iso} name={selected.name} />
          <div className="min-w-0 flex-1">
            <div className="font-display text-xl font-medium leading-tight">{selected.name}</div>
            <div className="text-sm text-muted">Capital {selected.capital}</div>
          </div>
          {props.mastered.has(selected.iso) && <Check className="size-4 text-sage" />}
        </div>
      )}

      <input
        type="search"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search countries or capitals"
        className="mt-5 h-11 w-full rounded-md border border-border bg-surface px-3 text-sm text-fg placeholder:text-subtle"
      />

      <ul className="mt-3 grid grid-cols-1 gap-1 sm:grid-cols-2">
        {filtered.map((c) => {
          const on = props.mastered.has(c.iso);
          const active = selected?.iso === c.iso;
          return (
            <li key={c.iso}>
              <button
                type="button"
                onClick={() => setSelected(c)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-md px-2 py-2 text-left",
                  active ? "bg-raised ring-1 ring-border-strong" : on ? "bg-raised/60" : "opacity-55",
                )}
              >
                <MiniFlag iso={c.iso} name={c.name} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">{c.name}</div>
                  <div className="truncate text-xs text-muted">{c.capital}</div>
                </div>
                {on && <Check className="size-4 shrink-0 text-sage" />}
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
